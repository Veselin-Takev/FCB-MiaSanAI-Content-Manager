const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const targetStr = `                                                      {statusArray.map(s => (
                                                        <div key={s.name} className="flex items-center gap-1 bg-slate-900/60 border border-slate-800 rounded px-1.5 py-0.5" title={\`\${s.label}: \${s.count}\`}>
                                                          <div className={\`h-1.5 w-1.5 rounded-full \${s.color !== 'custom' ? s.color : ''}\`} style={s.color === 'custom' ? { backgroundColor: s.hex } : {}} />
                                                          <span className="text-[7.5px] font-mono text-slate-300">{s.label} <span className="text-slate-500 font-bold ml-0.5">{s.count}</span></span>
                                                        </div>
                                                      ))}
                                                    </div>`;

const replaceStr = `                                                      {statusArray.map(s => (
                                                        <div key={s.name} className="flex items-center gap-1 bg-slate-900/60 border border-slate-800 rounded px-1.5 py-0.5" title={\`\${s.label}: \${s.count}\`}>
                                                          <div className={\`h-1.5 w-1.5 rounded-full \${s.color !== 'custom' ? s.color : ''}\`} style={s.color === 'custom' ? { backgroundColor: s.hex } : {}} />
                                                          <span className="text-[7.5px] font-mono text-slate-300">{s.label} <span className="text-slate-500 font-bold ml-0.5">{s.count}</span></span>
                                                        </div>
                                                      ))}
                                                      <button
                                                        type="button"
                                                        onClick={() => {
                                                          const activeIds = activePresets.map(p => p.id);
                                                          setExportPresets(prev => prev.map(p => {
                                                            if (activeIds.includes(p.id)) {
                                                              const currentStatus = p.status || "Draft";
                                                              if (currentStatus === "Draft") return { ...p, status: "Needs Work" };
                                                              if (currentStatus === "Needs Work") return { ...p, status: "Draft" };
                                                            }
                                                            return p;
                                                          }));
                                                        }}
                                                        className="ml-auto flex items-center gap-1 text-[7px] font-bold uppercase tracking-wider bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded border border-slate-700 transition"
                                                        title={language === "de" ? "Status für alle aktiven Presets umschalten (Draft ↔ Needs Work)" : "Toggle QA Status for all filtered presets (Draft ↔ Needs Work)"}
                                                      >
                                                        <CheckCircle2 className="h-2.5 w-2.5 text-amber-400" />
                                                        {language === "de" ? "QA-Status umschalten" : "Toggle QA Status"}
                                                      </button>
                                                    </div>`;

if (code.includes(targetStr)) {
  code = code.replace(targetStr, replaceStr);
  fs.writeFileSync('src/App.tsx', code);
  console.log("Successfully replaced.");
} else {
  console.log("Target string not found in src/App.tsx.");
}
