const fs = require('fs');
let code = fs.readFileSync('src/components/CategoryManager.tsx', 'utf8');

// Update renderNode
const renderNodeStart = `  const renderNode = (node: TreeNode, level: number) => {`;
const renderNodeEndRegex = /<div className="ml-4 pl-2 border-l border-slate-700\/50 flex flex-col mt-0\.5 gap-0\.5">[\s\S]*?<\/div>\n\s*\)\}\n\s*<\/div>\n\s*\);\n\s*\};/;

const newRenderNode = `  const renderNode = (node: TreeNode, level: number) => {
    if (node.type === "preset") {
      return (
        <div key={node.path} className="w-full flex items-center gap-2 py-1.5 px-2 rounded-lg hover:bg-slate-800/30 transition-colors">
          <div className="w-4.5 flex justify-center items-center h-full opacity-40">
             <CornerDownRight className="w-3.5 h-3.5 text-slate-500" />
          </div>
          <FileText className="w-3.5 h-3.5 text-slate-400" />
          <span className="text-xs text-slate-400 truncate flex-1" title={node.preset?.id}>{node.name}</span>
          <span className="text-[9px] text-slate-500 font-mono opacity-50 truncate max-w-[80px]">{node.preset?.id}</span>
        </div>
      );
    }

    const isEditing = editingPath === node.path;
    const isDragTarget = draggedPath && draggedPath !== node.path && !node.path.startsWith(draggedPath + "/");

    return (
      <div key={node.path} className="w-full">
        <div 
          className={\`flex items-center gap-1.5 py-1.5 px-2 rounded-lg group transition-colors relative
            \${isDragTarget ? "bg-cyan-900/30 ring-1 ring-cyan-500/50" : "hover:bg-slate-800/40"}\`}
          draggable={node.path !== ""}
          onDragStart={(e) => {
            e.stopPropagation();
            setDraggedPath(node.path);
          }}
          onDragOver={(e) => {
            e.preventDefault();
            e.stopPropagation();
          }}
          onDrop={(e) => {
            e.preventDefault();
            e.stopPropagation();
            if (draggedPath && draggedPath !== node.path) {
              handleMove(draggedPath, node.path);
            }
            setDraggedPath(null);
          }}
          onDragEnd={() => setDraggedPath(null)}
        >
          {node.children.length > 0 ? (
            <button 
              onClick={() => toggleExpand(node.path)}
              className="p-0.5 hover:bg-slate-700 rounded text-slate-400 transition-colors z-10 bg-slate-900/50 group-hover:bg-transparent"
            >
              {expandedPaths.has(node.path) || searchQuery.trim().length > 0 ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
            </button>
          ) : (
            <div className="w-4.5 flex justify-center items-center h-full opacity-40">
               <CornerDownRight className="w-3.5 h-3.5 text-slate-500" />
            </div>
          )}
          
          <Folder className={\`w-4 h-4 \${node.path === "" ? "text-amber-500" : "text-cyan-500"}\`} />
          
          {isEditing && node.path !== "" ? (
            <div className="flex items-center gap-1 flex-1">
              <input
                autoFocus
                value={editValue}
                onChange={e => setEditValue(e.target.value)}
                onKeyDown={e => {
                  if (e.key === "Enter") handleRename(node.path, editValue);
                  if (e.key === "Escape") setEditingPath(null);
                }}
                className="bg-slate-950 border border-cyan-500/50 rounded px-2 py-0.5 text-xs text-white focus:outline-none focus:border-cyan-400 w-full max-w-[200px]"
              />
              <button onClick={() => handleRename(node.path, editValue)} className="p-1 text-emerald-400 hover:bg-slate-800 rounded"><Check className="w-3.5 h-3.5" /></button>
              <button onClick={() => setEditingPath(null)} className="p-1 text-rose-400 hover:bg-slate-800 rounded"><X className="w-3.5 h-3.5" /></button>
            </div>
          ) : (
            <span className={\`text-xs flex-1 select-none font-medium truncate \${node.path === "" ? "text-amber-400" : "text-slate-200"}\`}>
              {node.name || "Root"}
            </span>
          )}

          {node.path !== "" && !isEditing && (
            <div className="opacity-0 group-hover:opacity-100 flex items-center gap-1">
              <button
                onClick={() => {
                  setEditingPath(node.path);
                  setEditValue(node.name);
                }}
                className="p-1.5 text-slate-400 hover:text-cyan-400 hover:bg-slate-800 rounded transition-colors"
                title={language === "de" ? "Umbenennen" : "Rename"}
              >
                <Edit2 className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
        
        {(expandedPaths.has(node.path) || searchQuery.trim().length > 0) && node.children.length > 0 && (
          <div className="ml-4 pl-2 border-l border-slate-700/50 flex flex-col mt-0.5 gap-0.5">
            {node.children.map(child => renderNode(child, level + 1))}
          </div>
        )}
      </div>
    );
  };`;

code = code.replace(/  const renderNode = \(node: TreeNode, level: number\) => \{[\s\S]*?<div className="ml-4 pl-2 border-l border-slate-700\/50 flex flex-col mt-0\.5 gap-0\.5">[\s\S]*?<\/div>\n\s*\)\}\n\s*<\/div>\n\s*\);\n\s*\};/, newRenderNode);

// Now update the header to include search input
const headerOld = `      <div className="p-4 border-b border-slate-800 bg-slate-950 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Folder className="w-4.5 h-4.5 text-cyan-500" />
            {language === "de" ? "Kategorien Verwalten" : "Category Manager"}
          </h3>
          <p className="text-[10px] text-slate-400 mt-1">
            {language === "de" 
              ? "Ordner ziehen, um sie zu verschieben. Klicken zum Umbenennen." 
              : "Drag folders to move them. Click edit to rename."}
          </p>
        </div>
        {onClose && (
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg">
            <X className="w-4 h-4" />
          </button>
        )}
      </div>`;

const headerNew = `      <div className="p-4 border-b border-slate-800 bg-slate-950">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Folder className="w-4.5 h-4.5 text-cyan-500" />
              {language === "de" ? "Kategorien Verwalten" : "Category Manager"}
            </h3>
            <p className="text-[10px] text-slate-400 mt-1">
              {language === "de" 
                ? "Ordner ziehen, um sie zu verschieben. Klicken zum Umbenennen." 
                : "Drag folders to move them. Click edit to rename."}
            </p>
          </div>
          {onClose && (
            <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg">
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
        
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input 
            type="text"
            placeholder={language === "de" ? "Presets nach Name oder ID filtern..." : "Filter presets by name or ID..."}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-500/50 transition-colors"
          />
        </div>
      </div>`;

code = code.replace(headerOld, headerNew);

fs.writeFileSync('src/components/CategoryManager.tsx', code);
console.log("Patched renderNode and header!");
