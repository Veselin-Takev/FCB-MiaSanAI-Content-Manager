const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

// 1. Replace the button click
code = code.replace(/setShowCategoryManagerModal\(true\)/g, "setShowCategoryManager(true)");

// 2. Add pushToUndoStack to the CategoryManager onUpdatePresets handler
const oldHandler = `                onUpdatePresets={(updated) => {
                  setExportPresets(updated);
                  setNotification(language === "de" ? "Kategorien erfolgreich aktualisiert." : "Categories updated successfully.");
                }}`;

const newHandler = `                onUpdatePresets={(updated) => {
                  pushToUndoStack("Batch updated categories", "Kategorien massenhaft aktualisiert");
                  setExportPresets(updated);
                  try {
                    localStorage.setItem("fcb_miasanai_export_presets", JSON.stringify(updated));
                  } catch(e) {}
                  setNotification(language === "de" ? "Kategorien erfolgreich aktualisiert." : "Categories updated successfully.");
                }}`;

code = code.replace(oldHandler, newHandler);

// 3. Remove showCategoryManagerModal entirely
const regexModal = /<AnimatePresence>\s*\{showCategoryManagerModal && \([\s\S]*?<\/motion\.div>\s*<\/div>\s*<\/motion\.div>\s*<\/motion\.div>\s*\)\}\s*<\/AnimatePresence>/g;
code = code.replace(regexModal, "");

// Wait, looking at the grep earlier:
// 14495-      <AnimatePresence>
// 14496:        {showCategoryManagerModal && (
// 14497-          <motion.div
// ...
// 14595-          </motion.div>
// 14596-        )}
// 14597-      </AnimatePresence>
// It spans about 100 lines. The regex above might not match if it contains AnimatePresence inside or not enough closing divs.
// I'll just use a start and end index to delete it precisely.

fs.writeFileSync('src/App.tsx', code);
console.log("Patched category manager usages.");
