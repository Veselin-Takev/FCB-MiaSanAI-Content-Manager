const fs = require('fs');
let code = fs.readFileSync('src/components/CategoryManager.tsx', 'utf8');

if (!code.includes('Search')) {
  code = code.replace(/import {([^}]+)} from "lucide-react";/, (match, p1) => {
    return `import {${p1}, Search, FileText} from "lucide-react";`;
  });
}

// Update CategoryManagerProps if ExportPreset is not imported
if (!code.includes('import { ExportPreset }')) {
  code = `import { ExportPreset } from "../types";\n` + code;
}

// Update TreeNode
code = code.replace(/interface TreeNode \{[\s\S]*?\}/, `interface TreeNode {
  name: string;
  path: string;
  type: "folder" | "preset";
  children: TreeNode[];
  isExpanded: boolean;
  preset?: ExportPreset;
}`);

// Add searchQuery state
const stateInsert = `  const [draggedPath, setDraggedPath] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>("");`;
code = code.replace(/  const \[draggedPath, setDraggedPath\] = useState<string \| null>\(null\);/, stateInsert);

// Update tree memo
const treeMemoOld = `  const tree = useMemo(() => {
    const categories = Array.from(new Set(presets.map(p => p.category).filter(Boolean))) as string[];
    
    // Ensure all intermediate paths exist
    const allPaths = new Set<string>();
    categories.forEach(cat => {
      const parts = cat.split("/");
      let curr = "";
      parts.forEach(part => {
        curr = curr ? \`\${curr}/\${part}\` : part;
        allPaths.add(curr);
      });
    });

    const root: TreeNode = { name: "Root", path: "", children: [], isExpanded: true };
    const nodeMap = new Map<string, TreeNode>();
    
    // Sort paths by length so we create parents before children
    const sortedPaths = Array.from(allPaths).sort((a, b) => a.split("/").length - b.split("/").length);
    
    sortedPaths.forEach(path => {
      const parts = path.split("/");
      const name = parts[parts.length - 1];
      const parentPath = parts.slice(0, -1).join("/");
      
      const node: TreeNode = {
        name,
        path,
        children: [],
        isExpanded: expandedPaths.has(path)
      };
      nodeMap.set(path, node);
      
      if (parentPath === "") {
        root.children.push(node);
      } else {
        const parent = nodeMap.get(parentPath);
        if (parent) parent.children.push(node);
      }
    });

    // Sort children alphabetically
    const sortNode = (node: TreeNode) => {
      node.children.sort((a, b) => a.name.localeCompare(b.name));
      node.children.forEach(sortNode);
    };
    sortNode(root);

    return root;
  }, [presets, expandedPaths]);`;

const treeMemoNew = `  const tree = useMemo(() => {
    let filteredPresets = presets;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      filteredPresets = presets.filter(p => 
        p.name.toLowerCase().includes(q) || 
        p.id.toLowerCase().includes(q)
      );
    }

    const categories = Array.from(new Set(presets.map(p => p.category).filter(Boolean))) as string[];
    
    // Ensure all intermediate paths exist
    const allPaths = new Set<string>();
    categories.forEach(cat => {
      const parts = cat.split("/");
      let curr = "";
      parts.forEach(part => {
        curr = curr ? \`\${curr}/\${part}\` : part;
        allPaths.add(curr);
      });
    });

    const root: TreeNode = { name: "Root", path: "", type: "folder", children: [], isExpanded: true };
    const nodeMap = new Map<string, TreeNode>();
    
    // Sort paths by length so we create parents before children
    const sortedPaths = Array.from(allPaths).sort((a, b) => a.split("/").length - b.split("/").length);
    
    sortedPaths.forEach(path => {
      const parts = path.split("/");
      const name = parts[parts.length - 1];
      const parentPath = parts.slice(0, -1).join("/");
      
      const node: TreeNode = {
        name,
        path,
        type: "folder",
        children: [],
        isExpanded: expandedPaths.has(path) || searchQuery.length > 0 // auto expand on search
      };
      nodeMap.set(path, node);
      
      if (parentPath === "") {
        root.children.push(node);
      } else {
        const parent = nodeMap.get(parentPath);
        if (parent) parent.children.push(node);
      }
    });

    // Add presets as children
    filteredPresets.forEach(preset => {
      const parentPath = preset.category || "";
      const presetNode: TreeNode = {
        name: preset.name,
        path: \`\${parentPath}/__preset__\${preset.id}\`,
        type: "preset",
        children: [],
        isExpanded: false,
        preset
      };
      
      if (parentPath === "") {
        root.children.push(presetNode);
      } else {
        const parent = nodeMap.get(parentPath);
        if (parent) parent.children.push(presetNode);
      }
    });

    // Prune empty folders if searching
    if (searchQuery.trim()) {
      const pruneEmpty = (node: TreeNode): boolean => {
        if (node.type === "preset") return true;
        node.children = node.children.filter(pruneEmpty);
        return node.children.length > 0;
      };
      root.children = root.children.filter(pruneEmpty);
    }

    // Sort children alphabetically (folders first, then presets)
    const sortNode = (node: TreeNode) => {
      node.children.sort((a, b) => {
        if (a.type !== b.type) return a.type === "folder" ? -1 : 1;
        return a.name.localeCompare(b.name);
      });
      node.children.forEach(sortNode);
    };
    sortNode(root);

    return root;
  }, [presets, expandedPaths, searchQuery]);`;

code = code.replace(treeMemoOld, treeMemoNew);

fs.writeFileSync('src/components/CategoryManager.tsx', code);
console.log("Patched tree logic!");
