export interface SquadPlayer {
  name: string;
  number: number;
  position: string;
  nationality: string;
  personality: string;
  key_stats: string;
  imageUrl: string;
}

export interface SocialPost {
  imageUrl?: string;
  headline: string;
  caption: string;
  hashtags: string[];
  visualSuggestion: string;
  engagementTriggers: string[];
}

export interface JourneyStage {
  id: string;
  name: string;
  description: string;
  color: string;
  triggers: { id: string; name: string; description: string }[];
  actions: { id: string; name: string; description: string }[];
}

export interface AutomatedStep {
  triggerDetected: string;
  automatedActionName: string;
  personalizedMessage: string;
  interactiveCTA: string;
  middlewarePayload: any;
}

export interface VideoScene {
  timestamp: string;
  visualPrompt: string;
  audioSoundtrack: string;
  voiceoverScript: string;
}

export interface VideoStoryboard {
  videoTitle: string;
  hookText: string;
  scenes: VideoScene[];
  aiToolchain: string;
}

export interface RagResult {
  retrievedDocs: { source: string; snippet: string; score?: number; rerankScore?: number }[];
  ragResponse: string;
  brandAlignmentRating: string;
  isSimulated?: boolean;
  isCached?: boolean;
  metrics?: {
    faithfulness: number;
    answerRelevance: number;
    contextRecall: number;
    contextPrecision: number;
  };
}

export interface PipelineLog {
  id: string;
  timestamp: string;
  level: "INFO" | "SUCCESS" | "WARNING" | "ERROR" | "TRIGGER";
  source: string;
  message: string;
}

export interface DraftSocialPost {
  id: string;
  headline: string;
  caption: string;
  hashtags: string[];
  platform: string;
  playerName: string;
  status: "pending" | "approved" | "published";
  createdAt: string;
}

export interface AutomationWorkflow {
  id: string;
  name: string;
  triggerEvent: string;
  connector: "Zapier" | "n8n" | "Make.com" | "Internal";
  status: "active" | "inactive";
  executionsCount: number;
}
export interface SmartCollection {
  id: string;
  name: string;
  filters: {
    status?: string | null;
    tags?: string[];
    seasons?: string[];
    matchdays?: string[];
    search?: string;
    category?: string;
    includeSubfolders?: boolean;
    logic?: "AND" | "OR";
  };
}

export interface PresetSet {
  id: string;
  name: string;
  tag: string;
  presetIds: string[];
}

export interface ExportPreset {
  id: string;
  name: string;
  nameDe?: string;
  description: string;
  descriptionDe?: string;
  notes?: string;
  tags?: string[];
  season?: string;
  seasons?: string[];
  matchday?: string;
  matchdays?: string[];
  category?: string;
  status?: string;
  statusHistory?: any[];
  usageCount?: number;
  lastUsed?: number;
  timestamp?: number;
  usageHistory?: number[];
  isFavorite?: boolean;
  isHighlighted?: boolean;
  colorCode?: string;
  impactForecast?: string;
  compressorEnabled?: boolean;
  isNormalized?: boolean;
  fadeInDuration?: number;
  fadeOutDuration?: number;
  noiseGateThreshold?: number;
  compLowThreshold?: number;
  compLowRatio?: number;
  compLowMakeup?: number;
  compMidThreshold?: number;
  compMidRatio?: number;
  compMidMakeup?: number;
  compHighThreshold?: number;
  compHighRatio?: number;
  compHighMakeup?: number;
  pendingSync?: boolean;
  cloneCount?: number;
  version?: number;
  versionHistory?: { version: number, timestamp: number, description?: string, snapshot?: Partial<ExportPreset> }[];
}
