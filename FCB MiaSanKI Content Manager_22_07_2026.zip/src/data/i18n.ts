export type Language = "de" | "en";

export const translations = {
  de: {
    "log.trigger": "Trigger-Pipeline wird ausgeführt für Fan '{fanName}' in Stufe: {stageName}. Trigger-Event: '{trigger}'",
    "log.success": "Automatisierte Aktion erfolgreich ausgeführt: '{action}'. Payload an Kanäle weitergeleitet. Fan wurde benachrichtigt.",
    "log.error": "Fehler bei der Ausführung der Automatisierung: {error}",

    "field.fan_name.placeholder": "Fan-Namen eingeben...",

    "step.1.title": "Schritt 1: Fan-Signal",
    "step.1.desc": "Fan führt ein Trigger-Event aus (NFC-Zutritt, Highscore oder Tag). Erfasst über Zapier oder n8n Webhooks.",
    "step.2.title": "Schritt 2: KI-Kontext-Grounding",
    "step.2.desc": "MiaSanAI ruft Kader-Statistiken und Brand-Safety-Filter aus dem internen Wissensspeicher (RAG) ab.",
    "step.3.title": "Schritt 3: Ausgabekanal",
    "step.3.desc": "Generiert maßgeschneiderte Texte, personalisierte Spieler-Bildvorlagen oder Sprachskripte und liefert diese sofort aus.",
    "terminal.header": "MiaSanAI Terminal-Monitor",
    "terminal.generating": "Journey-Pipeline wird generiert...",
    "terminal.log1": "⚡ [LOG 13:03] Verbindung zum Gemini LLM-Orchestrator wird hergestellt...",
    "terminal.log2": "⚡ [LOG 13:03] Grounding der Antwort mit RAG-Parametern...",
    "terminal.log3": "⚡ [LOG 13:03] Strukturelles Antwort-Schema wird verarbeitet...",
    "terminal.trigger_confirmed": "SYSTEM-TRIGGER BESTÄTIGT",
    "terminal.mobile_preview": "Fan-Mobilgeräte-Vorschau",
    "terminal.just_now": "Gerade eben",
    "terminal.webhook": "🔄 Middleware Webhook Payload (n8n Routing)",

    // System & Header
    "nav.lifecycle": "Kundenreise-Automatisierung",
    "system.notice": "Arbeitsbereich gewechselt zu Lifecycle-Engine",
    "action.voice": "SPRACHBEFEHL",
    
    // Lifecycle Journey Mapper (Cards)
    "card.1.title": "1. Wahrnehmung & Reichweite",
    "card.1.desc": "Gelegenheitsfans ansprechen und virale Reichweite erzielen...",
    "card.2.title": "2. Aktive Einbindung",
    "card.2.desc": "Social-Media-Follower zu interaktiver Teilnahme bewegen...",
    "card.3.title": "3. Fanshop & Ticket-Konvertierung",
    "card.3.desc": "Merchandise-Verkäufe und Mitgliedschaften fördern...",
    "card.4.title": "4. Fan-Bindung & Loyalität",
    "card.4.desc": "Einmalkäufer zu lebenslangen Fans entwickeln...",
    
    // Automation Engine Parameters (Form)
    "section.title": "Automatisierungs-Parameter",
    "field.fan_name": "ZIEL-FANNAME",
    "field.fan_name.desc": "Dient der dynamischen Personalisierung von KI-Vorlagen.",
    "field.trigger": "AKTIVE TRIGGER-BEDINGUNG",
    "field.trigger.desc": "Simuliert Fan-Aktionen zur Auslösung von n8n/Zapier.",
    "field.action": "ZIEL-CONTENT-AKTION",
    "field.action.desc": "Der auszuführende Generative-KI-Workflow.",
    "btn.execute": "Reise-Automatisierung ausführen",
    
    // Terminal Monitor
    "terminal.placeholder": "Konfigurieren Sie die Fan-Details und Trigger auf der linken Seite. Starten Sie anschließend die Pipeline, um die KI-Ausgabe zu sehen.",
    "footer.how_it_works": "Funktionsweise der MiaSanAI Middleware-Engine:",

    // General Brand & Headers
    appName: "MiaSanAI",
    enterprise: "Enterprise",
    subHeader: "Automatisierte Customer-Journey & Social-Media-Pipeline • FC Bayern München",
    secureBadge: "SSL SICHERE ZENTRALE",
    footerText: "© 2026 FC Bayern München AG | „MiaSanAI“ Enterprise Social Management Pipeline",
    footerSubText: "Grounding-Engine angetrieben durch Google Gemini 3.5 Flash & Antigravity Orchestrator",
    notificationOnline: "MiaSanAI Engine online: Grounded RAG-Datenbanken und Express-API-Server laufen normal.",
    workspaceShifted: "Arbeitsbereich gewechselt zu ",
    automationSuccess: "Automations-Erfolg: ",
    workflowTriggered: "Workflow ausgelöst: ",
    simulatedTrigger: "Simulierter Trigger empfangen. Überprüfen Sie das Terminal.",

    // Navigation Tabs
    tabDashboard: "Kommandozentrale",
    tabDashboardDesc: "System-KPIs & Live-Logs",
    tabJourney: "Lifecycle-Engine",
    tabJourneyDesc: "Kundenreise-Automatisierung",
    tabGenerator: "Multi-Format-Generator",
    tabGeneratorDesc: "Post-Generierung & Canvas-Builder",
    tabModeration: "Freigabe & Moderation",
    tabModerationDesc: "Marken-Compliance & Freigaben",
    tabVideo: "Video-Studio",
    tabVideoDesc: "Generativer Video-Planer",
    tabRag: "FCB-Wissensdatenbank",
    tabRagDesc: "RAG-Vektorabfragesystem",
    tabAutomation: "Webhook-Pipeline",
    tabAutomationDesc: "n8n & Zapier Webhook-Router",
    tabLangGraph: "LangGraph-Orchestrator",
    tabLangGraphDesc: "Multi-Agenten-Netzwerk & Tracing",
    tabSettings: "Einstellungen",
    tabSettingsDesc: "Anzeige- & Systemkonfiguration",

    // Brand Compliance Side Panel
    brandComplianceTitle: "Marken-Compliance-Richtlinien",
    brandComplianceFooter: "Verifiziert durch FCB Corporate Compliance",

    // Language Toggle
    toggleLanguage: "Sprache wechseln",

    // Content Generator tab additions
    addDraftQueue: "Entwurf zur Kampagnen-Warteschlange hinzufügen",
    draftsQueued: "ENTWÜRFE IN WARTESCHLANGE",
    liveCampaignQueue: "Live-Kampagnen-Warteschlange",
    liveCampaignQueueDesc: "Verwalten Sie mehrere KI-generierte Entwürfe für die offizielle Freigabe und Veröffentlichung.",
    selectAll: "Alle auswählen",
    deselectAll: "Auswahl aufheben",
    tableSelect: "Auswahl",
    tableChannel: "Kanal",
    tablePlayer: "Spieler",
    tableHeadline: "Schlagzeile & Vorschau",
    tableAdded: "Hinzugefügt",
    tableStatus: "Status",
    tableDelete: "Löschen",
    noDrafts: "Die Entwurfswarteschlange ist leer. Erstellen Sie oben einen Entwurf.",
    batchManager: "Sammel-Kampagnen-Manager",
    selectedDraftsCount: "Entwürfe ausgewählt",
    batchApprove: "Sammel-Freigabe",
    batchPublish: "Sammel-Veröffentlichung",
    dispatching: "Senden...",
    schedule: "Planen",
    export: "Exportieren",
    archive: "Archivieren",
    copied: "Kopiert!",
    copySnippet: "Ausschnitt kopieren",
    reindexChunk: "Chunk neu indizieren",
    reindexing: "Indizierung...",
    downloadGrounded: "Grundlagedokument herunterladen"
  },
  en: {
    "log.trigger": "Running trigger pipeline for fan '{fanName}' in stage: {stageName}. Trigger event: '{trigger}'",
    "log.success": "Successfully executed automated action: '{action}'. Payload routed to channels. Fan notified.",
    "log.error": "Error executing step automation: {error}",

    "field.fan_name.placeholder": "Enter fan's name...",

    "step.1.title": "Step 1: Fan Signal",
    "step.1.desc": "Fan completes trigger event (NFC gate pass, high score, or tag). Ingested via Zapier or n8n webhooks.",
    "step.2.title": "Step 2: AI Context Grounding",
    "step.2.desc": "MiaSanAI fetches squad statistics and brand safety filters from our internal club knowledge repository (RAG).",
    "step.3.title": "Step 3: Delivery Channel",
    "step.3.desc": "Generates bespoke copywriting, customized player imagery templates, or voice scripts and delivers instantly.",
    "terminal.header": "MiaSanAI Terminal Monitor",
    "terminal.generating": "Generating Journey Pipeline...",
    "terminal.log1": "⚡ [LOG 13:03] Connecting to Gemini LLM orchestrator...",
    "terminal.log2": "⚡ [LOG 13:03] Grounding response with RAG parameters...",
    "terminal.log3": "⚡ [LOG 13:03] Parsing structural response schema...",
    "terminal.trigger_confirmed": "SYSTEM TRIGGER CONFIRMED",
    "terminal.mobile_preview": "Fan Mobile Device Preview",
    "terminal.just_now": "Just now",
    "terminal.webhook": "🔄 Middleware Webhook Payload (n8n Routing)",

    // System & Header
    "nav.lifecycle": "Customer Journey Automation",
    "system.notice": "Workspace switched to Lifecycle Engine",
    "action.voice": "VOICE COMMAND",
    
    // Lifecycle Journey Mapper (Cards)
    "card.1.title": "1. Awareness & Reach",
    "card.1.desc": "Capture casual fan attention and viral reach...",
    "card.2.title": "2. Active Engagement",
    "card.2.desc": "Get social followers to actively interact...",
    "card.3.title": "3. Fan Shop & Ticket Conversion",
    "card.3.desc": "Drive merchandise sales and memberships...",
    "card.4.title": "4. Loyalty & Fan Club Retention",
    "card.4.desc": "Turn transactional buyers into lifetime fans...",
    
    // Automation Engine Parameters (Form)
    "section.title": "Automation Engine Parameters",
    "field.fan_name": "TARGET FAN NAME",
    "field.fan_name.desc": "Used to personalize AI templates dynamically.",
    "field.trigger": "ACTIVE TRIGGER CONDITION",
    "field.trigger.desc": "Simulated fan actions that wake up n8n/Zapier.",
    "field.action": "TARGET CONTENT ACTION",
    "field.action.desc": "The Generative AI workflow that executes.",
    "btn.execute": "Execute Journey Automation",
    
    // Terminal Monitor
    "terminal.placeholder": "Configure the fan details and triggers on the left, then trigger the pipeline execution to watch the AI output.",
    "footer.how_it_works": "How the MiaSanAI Middleware Engine operates:",

    // General Brand & Headers
    appName: "MiaSanAI",
    enterprise: "Enterprise",
    subHeader: "Customer Journey Automation Engine • FC Bayern Munich",
    secureBadge: "SSL SECURE CORE",
    footerText: "© 2026 FC Bayern München AG | \"MiaSanAI\" Enterprise Social Management Pipeline",
    footerSubText: "Grounding Engine powered by Google Gemini 3.5 Flash & Antigravity Orchestrator",
    notificationOnline: "MiaSanAI Engine online: Grounded RAG databases and Express API server operating normally.",
    workspaceShifted: "Workspace shifted to ",
    automationSuccess: "Automation Success: ",
    workflowTriggered: "Workflow Triggered: ",
    simulatedTrigger: "Simulated Trigger received. Review results inside the terminal.",

    // Navigation Tabs
    tabDashboard: "Command Center",
    tabDashboardDesc: "System KPIs & Live logs",
    tabJourney: "Lifecycle Engine",
    tabJourneyDesc: "Customer journey automation",
    tabGenerator: "AI Multi-Format Generator",
    tabGeneratorDesc: "Post generation & canvas builder",
    tabModeration: "Moderation & Approvals",
    tabModerationDesc: "Brand compliance & approvals",
    tabVideo: "Runway Video Director",
    tabVideoDesc: "AI generative video planner",
    tabRag: "FCB Knowledge Hub",
    tabRagDesc: "RAG vector retrieval system",
    tabAutomation: "Middleware Connectors",
    tabAutomationDesc: "n8n & Zapier webhook router",
    tabLangGraph: "LangGraph Orchestrator",
    tabLangGraphDesc: "Multi-Agentic Trace & Loops",
    tabSettings: "Settings",
    tabSettingsDesc: "Display & system configuration",

    // Brand Compliance Side Panel
    brandComplianceTitle: "Brand Compliance Rules",
    brandComplianceFooter: "Verified by FCB Corporate Compliance",

    // Language Toggle
    toggleLanguage: "Switch Language",

    // Content Generator tab additions
    addDraftQueue: "Add Draft to Campaign Queue",
    draftsQueued: "DRAFTS QUEUED",
    liveCampaignQueue: "Live Campaign Drafts Queue",
    liveCampaignQueueDesc: "Manage and queue multiple AI-generated social platform posts for official approval and dispatch.",
    selectAll: "Select All",
    deselectAll: "Deselect All",
    tableSelect: "Select",
    tableChannel: "Channel",
    tablePlayer: "Featured Player",
    tableHeadline: "Caption Headline & Snippet",
    tableAdded: "Added",
    tableStatus: "Status",
    tableDelete: "Delete",
    noDrafts: "The drafts queue is currently empty. Generate a draft above and click 'Add Draft to Campaign Queue' to start.",
    batchManager: "Batch Campaign Manager",
    selectedDraftsCount: "drafts selected",
    batchApprove: "Batch Approve",
    batchPublish: "Batch Publish Live",
    dispatching: "Dispatching...",
    schedule: "Schedule",
    export: "Export",
    archive: "Archive",
    copied: "Copied!",
    copySnippet: "Copy Snippet",
    reindexChunk: "Re-index Chunk",
    reindexing: "Re-indexing...",
    downloadGrounded: "Download Full Grounding Document"
  }
};
