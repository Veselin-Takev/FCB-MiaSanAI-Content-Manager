import { useState, useCallback } from "react";

export function useTelemetry(feedback: Record<string, "up" | "down">) {
  const [telemetryLogs, setTelemetryLogs] = useState<any[]>([]);
  const [isLoadingTelemetry, setIsLoadingTelemetry] = useState<boolean>(false);

  const fetchTelemetry = useCallback(async () => {
    setIsLoadingTelemetry(true);
    try {
      const response = await fetch("/api/rag/telemetry");
      const data = await response.json();
      if (data.logs) {
        // Also capture thumbs down feedbacks as telemetry
        const feedbackLogs = Object.entries(feedback)
          .filter(([_, val]) => val === "down")
          .map(([key, _]) => ({
            timestamp: new Date().toISOString(),
            query: `Feedback on ${key}`,
            maxScore: 0,
            type: "user_feedback_down"
          }));
        setTelemetryLogs([...data.logs, ...feedbackLogs].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()));
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoadingTelemetry(false);
    }
  }, [feedback]);

  return { telemetryLogs, isLoadingTelemetry, fetchTelemetry, setTelemetryLogs };
}
