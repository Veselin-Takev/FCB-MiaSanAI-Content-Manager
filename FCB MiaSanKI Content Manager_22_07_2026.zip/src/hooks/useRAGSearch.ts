import { useState, useCallback } from "react";
import { RagResult } from "../types";

interface UseRAGSearchOptions {
  userRole: string;
  onAddLog: (log: any) => void;
  uploadedDocs: any[];
}

export function useRAGSearch({ userRole, onAddLog, uploadedDocs }: UseRAGSearchOptions) {
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [result, setResult] = useState<RagResult | null>(null);
  const [chatHistory, setChatHistory] = useState<{role: 'user' | 'assistant', content: string}[]>([]);
  const [useMultiTurnMemory, setUseMultiTurnMemory] = useState<boolean>(false);

  const performSearch = useCallback(async (
    searchQuery: string,
    searchFilterCategory: string
  ) => {
    setIsLoading(true);
    setResult(null);

    if (useMultiTurnMemory) {
      setChatHistory(prev => [...prev, {role: 'user', content: searchQuery}]);
    } else {
      setChatHistory([{role: 'user', content: searchQuery}]);
    }

    try {
      const filters = searchFilterCategory !== "All" ? { category: searchFilterCategory } : undefined;
      const response = await fetch("/api/rag/search-stream", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          query: searchQuery, 
          filters, 
          userRole, 
          chatHistory: useMultiTurnMemory ? chatHistory.map(m => ({role: m.role, content: m.content})) : [] 
        })
      });

      if (!response.ok) {
        throw new Error("RAG retrieval failed");
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder("utf-8");
      
      let currentResult: RagResult = {
        retrievedDocs: [],
        ragResponse: "",
        brandAlignmentRating: "",
      };

      if (reader) {
        let done = false;
        let buffer = "";
        
        while (!done) {
          const { value, done: readerDone } = await reader.read();
          done = readerDone;
          if (value) {
            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split("\n\n");
            buffer = lines.pop() || "";
            
            for (const line of lines) {
              if (line.startsWith("data: ")) {
                try {
                  const eventData = JSON.parse(line.slice(6));
                  if (eventData.type === 'meta' || eventData.type === 'cache') {
                    // pre-calculate custom matches
                    const customMatchesList: any[] = [];
                    if (searchQuery && searchQuery.trim()) {
                      const queryLower = searchQuery.toLowerCase();
                      const queryWords = queryLower.split(/\s+/).filter(w => w.length > 2);
                      uploadedDocs.forEach(doc => {
                        let matchedIndex = -1;
                        for (const word of queryWords) {
                          const index = doc.content.toLowerCase().indexOf(word);
                          if (index !== -1) { matchedIndex = index; break; }
                        }
                        if (matchedIndex === -1) {
                          matchedIndex = doc.content.toLowerCase().indexOf(queryLower);
                        }
                        if (matchedIndex !== -1 || queryWords.length === 0) {
                          const start = Math.max(0, matchedIndex - 50);
                          const end = Math.min(doc.content.length, (matchedIndex !== -1 ? matchedIndex : 0) + 150);
                          let snippetText = doc.content.substring(start, end).trim();
                          if (start > 0) snippetText = "..." + snippetText;
                          if (end < doc.content.length) snippetText = snippetText + "...";
                          customMatchesList.push({
                            source: doc.source,
                            snippet: snippetText || doc.content.substring(0, 150)
                          });
                        }
                      });
                    }

                    // Apply re-ranking logic:
                    let docs = [...(eventData.data?.retrievedDocs || [])];
                    if (customMatchesList.length > 0 && searchQuery && searchQuery.trim()) {
                      // simple re-ranking mock combining local docs
                      docs = [...customMatchesList, ...docs].slice(0, 5);
                    }

                    currentResult = { ...currentResult, ...eventData.data, retrievedDocs: docs };
                    if (eventData.type === 'cache') {
                      currentResult.isCached = true;
                      onAddLog({
                        id: `rag-cache-${Date.now()}`,
                        timestamp: new Date().toLocaleTimeString(),
                        level: "INFO",
                        source: "Semantic Cache",
                        message: "Cache hit. Returning accelerated response."
                      });
                    }
                    setResult(currentResult);
                  } else if (eventData.type === 'chunk') {
                    currentResult = { ...currentResult, ragResponse: currentResult.ragResponse + eventData.data };
                    setResult(currentResult);
                  } else if (eventData.type === 'done') {
                    currentResult = { ...currentResult, ...eventData.data };
                    setResult(currentResult);
                    setChatHistory(prev => {
                       const h = [...prev];
                       if (h.length > 0 && h[h.length - 1].role === 'user') {
                           h.push({ role: 'assistant', content: currentResult.ragResponse });
                       } else if (h.length > 0 && h[h.length - 1].role === 'assistant') {
                           h[h.length - 1].content = currentResult.ragResponse;
                       }
                       return h;
                    });
                  } else if (eventData.type === 'error') {
                    currentResult = { ...currentResult, ragResponse: currentResult.ragResponse + "\n\n[Error: " + eventData.error + (eventData.details ? " - Rate Limit/Quota Exceeded" : "") + "]", isSimulated: true };
                    setResult(currentResult);
                  }
                } catch (e) {
                  // ignore parse error
                }
              }
            }
          }
        }
      }
    } catch (e: any) {
      setResult({
        retrievedDocs: [],
        ragResponse: "Sorry, I couldn't fetch the response. Please check your network or try again.",
        brandAlignmentRating: "N/A"
      });
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  }, [userRole, useMultiTurnMemory, chatHistory, uploadedDocs, onAddLog]);

  return {
    isLoading,
    result,
    setResult,
    chatHistory,
    useMultiTurnMemory,
    setUseMultiTurnMemory,
    performSearch,
    setChatHistory,
    setIsLoading
  };
}
