export interface SeedDocument {
  source: string;
  content: string;
  meta?: Record<string, unknown>;
}

export const FCB_KNOWLEDGE_SEED: SeedDocument[] = [
  {
    source: "tone-of-voice-guide",
    meta: { category: "Guidelines", type: "guideline", access_level: "public" },
    content: `FC Bayern Tone-of-Voice-Leitfaden. Die Kommunikation ist selbstbewusst, nahbar und stets faktisch korrekt. Kernwert ist das Vereinsmotto "Mia San Mia" – es steht für Zusammenhalt, Stolz und Bodenständigkeit. Der Ton ist enthusiastisch, aber niemals überheblich gegenüber Gegnern. Fans werden als "Familie" adressiert. Es werden keine unbelegten Behauptungen aufgestellt; im Zweifel wird auf gesicherte Fakten zurückgegriffen. Emotion und Respekt stehen im Gleichgewicht.`,
  },
  {
    source: "brand-guidelines",
    meta: { category: "Brand Assets", type: "guideline", access_level: "public" },
    content: `Markenrichtlinien. Primärfarben sind FCB-Rot und Weiß. Das Motto "Mia San Mia" soll in offiziellen Kampagnen präsent sein. Offizielle Hashtags sind #MiaSanMia und #FCBayern; kampagnenspezifische Tags werden ergänzt. Geschützte Logos, Sponsoren-Brandings und Spielerbildrechte dürfen nicht durch generative Modelle verfälscht werden. Visuelle KI-Inhalte werden auf symbolische, atmosphärische Motive beschränkt.`,
  },
  {
    source: "channel-style-matrix",
    meta: { category: "Guidelines", type: "guideline", access_level: "public" },
    content: `Kanal-Stilmatrix. Instagram: maximal ca. 150 Zeichen, visuelle Hook zuerst, Emojis erwünscht, maximal 2 Hashtags. LinkedIn: bis ca. 700 Zeichen, professioneller Ton, keine Emojis, kein Hashtag-Fokus. YouTube: dynamisches Skript mit Hook (0–15 Sekunden), etwa 90 Sekunden Erzählung und klarem Call-to-Action. TikTok/Reels: jugendlich, hook-first, hohe Energie.`,
  },
  {
    source: "club-facts",
    meta: { category: "General", type: "fact", access_level: "public" },
    content: `Der FC Bayern München wurde am 27. Februar 1900 gegründet und trägt seine Heimspiele in der Allianz Arena aus, die eine Kapazität von 75.000 Zuschauern hat. Die Profimannschaft der Herren gehört historisch zu den erfolgreichsten Vereinsmannschaften weltweit und hält den Rekord an nationalen Meisterschaften in Deutschland.`,
  },
  {
    source: "internal-sponsorship-agreements",
    meta: { category: "Internal", type: "fact", access_level: "restricted" },
    content: `STRICTLY CONFIDENTIAL: Interner Sponsoring-Vertrag mit der Allianz SE. Details: Die vertraglich vereinbarten Bonus-Zahlungen bei Erreichen des Champions-League-Halbfinales betragen 5 Millionen Euro. Bei diesem Dokument handelt es sich um interne Finanzdaten, die nicht öffentlich zugänglich gemacht werden dürfen. Ansprechpartner: Max Eberl, max.eberl@fcbayern.com, Tel: 0151-555-1234.`,
  },
  {
    source: "squad-planning-2027",
    meta: { category: "Internal", type: "fact", access_level: "restricted" },
    content: `STRICTLY CONFIDENTIAL: Kaderplanung für die Saison 2026/2027. Erste Scouting-Listen zeigen ein starkes Interesse an potenziellen Transfers im defensiven Mittelfeld. Freigaben für Budget bis zu 80 Mio. Euro wurden durch den Aufsichtsrat am 15. Juli bestätigt. Detaillierte Spielerprofile und Verhandlungsstände sind im internen Portal (Level 4) dokumentiert.`,
  },
  {
    source: "sponsor-communication-policy",
    meta: { category: "Contracts", type: "policy", access_level: "internal" },
    content: `Sponsoren-Kommunikationsrichtlinie. Sponsoren werden ausschließlich gemäß den vertraglich vereinbarten Platzierungs- und Nennungsregeln erwähnt. Vor der Veröffentlichung sind Sichtbarkeit von Sponsor-Logos und bindende rechtliche Klauseln zu prüfen. Es werden keine Produktversprechen oder Leistungsdaten von Sponsoren erfunden.`,
  },
  {
    source: "match-report-template",
    meta: { category: "Sporting & Squad Info", type: "template", note: "Format-Vorlage, kein reales Ergebnis", access_level: "public" },
    content: `Beispiel-Format für einen Spielbericht (Vorlage, keine realen Ergebnisse): Einleitung mit Paarung und Wettbewerb; Kernfakten (Ergebnis, Torschützen mit Minute, Zuschauerzahl); ein bis zwei taktische Beobachtungen; abschließendes emotionales Fazit im "Mia San Mia"-Ton. Sämtliche Zahlen sind aus den gelieferten Kerndaten zu übernehmen und niemals zu erfinden.`,
  },
  {
    source: "fcb-logo-official",
    meta: { category: "Brand Assets", type: "image", access_level: "public", imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/FC_Bayern_M%C3%BCnchen_logo_%282017%29.svg/1024px-FC_Bayern_M%C3%BCnchen_logo_%282017%29.svg.png" },
    content: "Offizielles FC Bayern München Logo (2017). Rundes Wappen mit bayrischem Rautenmuster in Blau und Weiß in der Mitte, umgeben von einem roten Ring mit der weißen Aufschrift 'FC BAYERN MÜNCHEN'.",
  },
  {
    source: "allianz-arena-night",
    meta: { category: "Stadium Operations", type: "image", access_level: "public", imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1c/Allianz_Arena_zu_verschiedenen_Zeiten.jpg/1280px-Allianz_Arena_zu_verschiedenen_Zeiten.jpg" },
    content: "Allianz Arena bei Nacht beleuchtet in Rot. Offizielles Pressefoto für Stadion-PR und Operations-Dokumente.",
  },
];