export interface GraphNode {
  id: string;
  type: string; // "Player", "Venue", "Concept", "Team"
  properties: Record<string, any>;
}

export interface GraphEdge {
  source: string;
  target: string;
  relation: string; // "PLAYS_FOR", "LOCATED_IN", "PART_OF"
}

export class KnowledgeGraph {
  nodes = new Map<string, GraphNode>();
  edges: GraphEdge[] = [];

  addNode(node: GraphNode) {
    if (!this.nodes.has(node.id)) {
      this.nodes.set(node.id, node);
    }
  }

  addEdge(edge: GraphEdge) {
    // Avoid exact duplicates
    if (!this.edges.some(e => e.source === edge.source && e.target === edge.target && e.relation === edge.relation)) {
      this.edges.push(edge);
    }
  }

  // Extract subgraph around mentioned entities
  extractSubgraph(query: string, maxDepth = 1) {
    const queryLower = query.toLowerCase();
    
    // 1. Find mentioned nodes
    const mentionedNodes = new Set<string>();
    for (const [id, node] of this.nodes.entries()) {
      if (queryLower.includes(id.toLowerCase())) {
        mentionedNodes.add(id);
      }
    }
    
    if (mentionedNodes.size === 0) return { nodes: [], edges: [] };

    const resultNodes = new Map<string, GraphNode>();
    const resultEdges: GraphEdge[] = [];
    
    let currentLevel = Array.from(mentionedNodes);
    
    for (let depth = 0; depth < maxDepth; depth++) {
      const nextLevel = new Set<string>();
      
      for (const nodeId of currentLevel) {
        if (!resultNodes.has(nodeId)) {
           resultNodes.set(nodeId, this.nodes.get(nodeId)!);
        }
        
        // Find edges connected to this node
        for (const edge of this.edges) {
          if (edge.source === nodeId || edge.target === nodeId) {
            resultEdges.push(edge);
            if (!resultNodes.has(edge.source)) nextLevel.add(edge.source);
            if (!resultNodes.has(edge.target)) nextLevel.add(edge.target);
          }
        }
      }
      currentLevel = Array.from(nextLevel);
    }

    // Deduplicate edges
    const uniqueEdges = [...new Set(resultEdges)];
    
    return {
      nodes: Array.from(resultNodes.values()),
      edges: uniqueEdges
    };
  }

  formatSubgraphAsText(subgraph: { nodes: GraphNode[], edges: GraphEdge[] }) {
    if (subgraph.nodes.length === 0) return "";
    let text = "Knowledge Graph Insights:\n";
    for (const edge of subgraph.edges) {
      const source = this.nodes.get(edge.source);
      const target = this.nodes.get(edge.target);
      if (source && target) {
        text += `- \${source.id} (\${source.type}) \${edge.relation} \${target.id} (\${target.type})\n`;
      }
    }
    return text;
  }
}

export const globalGraph = new KnowledgeGraph();

// Initialize with some FC Bayern seed data (Entity Extraction Simulation)
export function initializeGraph() {
  globalGraph.addNode({ id: "FC Bayern München", type: "Team", properties: {} });
  globalGraph.addNode({ id: "Allianz Arena", type: "Venue", properties: { capacity: 75000 } });
  globalGraph.addNode({ id: "Mia San Mia", type: "Concept", properties: {} });
  globalGraph.addNode({ id: "Thomas Müller", type: "Player", properties: { role: "Forward" } });
  globalGraph.addNode({ id: "Manuel Neuer", type: "Player", properties: { role: "Goalkeeper" } });
  globalGraph.addNode({ id: "Säbener Straße", type: "Venue", properties: { type: "Training Ground" } });
  
  globalGraph.addEdge({ source: "FC Bayern München", target: "Allianz Arena", relation: "PLAYS_AT" });
  globalGraph.addEdge({ source: "FC Bayern München", target: "Säbener Straße", relation: "TRAINS_AT" });
  globalGraph.addEdge({ source: "FC Bayern München", target: "Mia San Mia", relation: "CORE_PHILOSOPHY" });
  globalGraph.addEdge({ source: "Thomas Müller", target: "FC Bayern München", relation: "PLAYS_FOR" });
  globalGraph.addEdge({ source: "Manuel Neuer", target: "FC Bayern München", relation: "PLAYS_FOR" });
}

initializeGraph();
