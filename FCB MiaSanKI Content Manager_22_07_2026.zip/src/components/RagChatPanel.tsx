import React from "react";
import { RagResult } from "../types";
import { useLanguage } from "../context/LanguageContext";

interface RagChatPanelProps {
  chatHistory: { role: 'user' | 'assistant', content: string }[];
  result: RagResult;
  onExportCopy: () => void;
  onExportMarkdown: () => void;
  onExportPDF: () => void;
  onCitationClick: (sourceName: string, doc: any) => void;
}

export const RagChatPanel: React.FC<RagChatPanelProps> = ({
  chatHistory,
  result,
  onExportCopy,
  onExportMarkdown,
  onExportPDF,
  onCitationClick
}) => {
  const { language } = useLanguage();

  const renderRagResponseWithCitations = (text: string) => {
    // Matches [Source: whatever]
    const citationRegex = /\[Source:\s*([^\]]+)\]/gi;
    const parts = [];
    let lastIndex = 0;
    let match;

    while ((match = citationRegex.exec(text)) !== null) {
      if (match.index > lastIndex) {
        parts.push(<span key={lastIndex}>{text.substring(lastIndex, match.index)}</span>);
      }

      const sourceName = match[1].trim();
      const combinedDocs = result ? [...result.retrievedDocs] : [];
      const doc = combinedDocs.find(d => d.source.toLowerCase() === sourceName.toLowerCase());

      parts.push(
        <button
          key={match.index}
          className="inline-flex items-center gap-1 bg-fcb-red/15 hover:bg-fcb-red/25 border border-fcb-red/30 text-fcb-red font-mono text-[9px] font-bold px-1.5 py-0.5 rounded mx-1 align-middle transition cursor-pointer"
          onClick={() => {
            if (doc) {
              onCitationClick(sourceName, doc);
            }
          }}
          title={`View Source: ${sourceName}`}
        >
          {sourceName}
        </button>
      );
      lastIndex = match.index + match[0].length;
    }

    if (lastIndex < text.length) {
      parts.push(<span key={lastIndex}>{text.substring(lastIndex)}</span>);
    }

    return <>{parts}</>;
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-1.5">
        <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider block">
          {language === "de" ? "Fundierte KI-Antwort (Grounded)" : "Grounded AI Response"}
        </span>
        <div className="flex items-center gap-2">
          <button onClick={onExportCopy} className="p-1 hover:bg-slate-900 rounded text-slate-400 hover:text-cyan-400 transition" title={language === "de" ? "Kopieren" : "Copy to Clipboard"}>
            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>
          </button>
          <button onClick={onExportMarkdown} className="p-1 hover:bg-slate-900 rounded text-slate-400 hover:text-cyan-400 transition" title={language === "de" ? "Als Markdown exportieren" : "Download Markdown"}>
            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/><path d="M8 13v5"/><path d="m8 13 2 2"/><path d="m8 13-2 2"/><path d="m14 18 2-2"/><path d="m16 16-2-2"/><path d="m16 16 2 2"/></svg>
          </button>
          <button onClick={onExportPDF} className="p-1 hover:bg-slate-900 rounded text-slate-400 hover:text-cyan-400 transition" title={language === "de" ? "Als PDF exportieren" : "Download PDF"}>
            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/><path d="M8 18v-5.5a.5.5 0 0 1 .5-.5h1.5a1.5 1.5 0 0 1 0 3H8"/><path d="M13 12h-1v6h1a2 2 0 0 0 0-4h-1"/><path d="M18 12h-2v6"/><path d="M16 15h1"/></svg>
          </button>
        </div>
      </div>
      <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs text-slate-200 leading-relaxed font-sans">
        {chatHistory.length > 0 && (
          <div className="space-y-4 mb-4 pb-4 border-b border-slate-800">
            {chatHistory.slice(0, -2).map((msg, idx) => (
              <div key={idx} className={`p-3 rounded-lg ${msg.role === 'user' ? 'bg-cyan-900/20 text-cyan-200' : 'bg-slate-900/50 text-slate-300'}`}>
                <div className="text-[9px] font-mono uppercase tracking-wider mb-1 opacity-50">{msg.role}</div>
                <div className="text-xs leading-relaxed">{msg.role === 'user' ? msg.content : renderRagResponseWithCitations(msg.content)}</div>
              </div>
            ))}
          </div>
        )}
        {chatHistory.length >= 2 && (
          <div className="mb-4 p-3 rounded-lg bg-cyan-900/20 text-cyan-200">
            <div className="text-[9px] font-mono uppercase tracking-wider mb-1 opacity-50">user</div>
            <div className="text-xs leading-relaxed">{chatHistory[chatHistory.length - 2].content}</div>
          </div>
        )}
        <div className="p-3 rounded-lg bg-slate-900/50 text-slate-300">
          <div className="text-[9px] font-mono uppercase tracking-wider mb-1 opacity-50">assistant</div>
          {renderRagResponseWithCitations(result.ragResponse)}
        </div>
      </div>
    </div>
  );
};
