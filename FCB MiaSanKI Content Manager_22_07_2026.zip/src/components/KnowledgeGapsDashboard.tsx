import React from "react";
import { RefreshCw, BarChart2 } from "lucide-react";
import { useLanguage } from "../context/LanguageContext";

interface KnowledgeGapsDashboardProps {
  telemetryLogs: any[];
  isLoadingTelemetry: boolean;
  fetchTelemetry: () => void;
  onCloseGap: (query: string) => void;
}

export const KnowledgeGapsDashboard: React.FC<KnowledgeGapsDashboardProps> = ({
  telemetryLogs,
  isLoadingTelemetry,
  fetchTelemetry,
  onCloseGap
}) => {
  const { language } = useLanguage();

  return (
    <div className="bg-slate-900/20 p-6 rounded-2xl border border-slate-800/80 space-y-6" id="rag-telemetry-view">
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div className="flex items-center gap-2.5">
          <BarChart2 className="h-5 w-5 text-cyan-400" />
          <h3 className="font-bold text-white font-display text-sm">
            {language === "de" ? "TELEMETRIE DASHBOARD & LÜCKEN" : "TELEMETRY DASHBOARD & GAPS"}
          </h3>
        </div>
        <button
          onClick={fetchTelemetry}
          className="bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 px-3 py-1.5 rounded-lg text-xs flex items-center gap-2 transition cursor-pointer"
        >
          <RefreshCw className={`h-3 w-3 ${isLoadingTelemetry ? "animate-spin text-cyan-400" : ""}`} />
          {language === "de" ? "Aktualisieren" : "Refresh"}
        </button>
      </div>
      <div className="space-y-4">
        {isLoadingTelemetry ? (
          <div className="flex justify-center p-8">
            <RefreshCw className="h-6 w-6 text-slate-500 animate-spin" />
          </div>
        ) : telemetryLogs.length === 0 ? (
          <div className="text-center p-8 text-slate-500 text-sm border border-dashed border-slate-800 rounded-xl bg-slate-950">
            {language === "de" ? "Keine Telemetriedaten gefunden. System läuft optimal." : "No telemetry data found. System is optimal."}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="p-3 font-semibold">Timestamp</th>
                  <th className="p-3 font-semibold">Query / Event</th>
                  <th className="p-3 font-semibold">Max Score</th>
                  <th className="p-3 font-semibold">Type</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {telemetryLogs.map((log, i) => (
                  <tr key={i} className="hover:bg-slate-900/40 transition">
                    <td className="p-3 text-slate-500 whitespace-nowrap">{new Date(log.timestamp).toLocaleString()}</td>
                    <td className="p-3 text-slate-300 font-sans">
                      {log.query}
                      {(log.type === 'no_results_retrieval' || log.type === 'low_confidence_retrieval') && (
                        <button
                          onClick={() => onCloseGap(log.query)}
                          className="ml-3 text-[10px] bg-cyan-900/30 text-cyan-400 hover:bg-cyan-900/60 px-2 py-1 rounded transition cursor-pointer"
                        >
                          {language === 'de' ? 'Lücke schließen' : 'Close Gap'}
                        </button>
                      )}
                    </td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${log.maxScore < 0.65 ? 'bg-amber-500/20 text-amber-400' : 'bg-green-500/20 text-green-400'}`}>
                        {log.maxScore.toFixed(4)}
                      </span>
                    </td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                        log.type === 'user_feedback_down' ? 'border-red-500/30 text-red-400 bg-red-500/10' :
                        log.type === 'no_results_retrieval' ? 'border-amber-500/30 text-amber-400 bg-amber-500/10' :
                        'border-blue-500/30 text-blue-400 bg-blue-500/10'
                      }`}>
                        {log.type.toUpperCase().replace(/_/g, ' ')}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
