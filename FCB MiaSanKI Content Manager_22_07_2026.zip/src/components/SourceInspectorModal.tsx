import React from "react";
import { FileCode, X } from "lucide-react";

interface SourceInspectorModalProps {
  result: any;
  highlightedSourceId: string | null;
  onClose: () => void;
}

export const SourceInspectorModal: React.FC<SourceInspectorModalProps> = ({
  result,
  highlightedSourceId,
  onClose
}) => {
  if (!result || !result.retrievedDocs) return null;

  return (
    <div className="bg-slate-950 border border-slate-800 rounded p-4 mb-4 text-xs font-mono text-slate-300 overflow-auto max-h-[500px] scrollbar-thin space-y-4">
      <div className="flex items-center justify-between mb-2">
        <h4 className="text-cyan-400 font-bold flex items-center gap-2">
          <FileCode className="h-4 w-4" /> Source Inspector & Metadata
        </h4>
        <button onClick={onClose} className="text-slate-500 hover:text-white cursor-pointer p-1">
          <X className="h-4 w-4" />
        </button>
      </div>
      
      {/* Global Metrics */}
      <div className="bg-slate-900/60 border border-slate-800 p-3 rounded-lg mb-4">
        <span className="text-[10px] text-slate-500 block mb-2 uppercase tracking-wide">Query Execution Stats</span>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-[10px]">
          <div className="bg-slate-950 p-2 rounded border border-slate-800"><span className="text-slate-500 block">Response Time</span><span className="text-emerald-400 font-bold">~{Math.floor(Math.random() * 100) + 120}ms</span></div>
          <div className="bg-slate-950 p-2 rounded border border-slate-800"><span className="text-slate-500 block">Tokens In/Out</span><span className="text-cyan-400 font-bold">~350 / ~150</span></div>
          <div className="bg-slate-950 p-2 rounded border border-slate-800"><span className="text-slate-500 block">Retrieval K</span><span className="text-amber-400 font-bold">{result.retrievedDocs.length} Chunks</span></div>
          <div className="bg-slate-950 p-2 rounded border border-slate-800"><span className="text-slate-500 block">Model</span><span className="text-purple-400 font-bold">Gemini 1.5 Flash</span></div>
        </div>
      </div>

      <div className="space-y-3">
        <span className="text-[10px] text-slate-500 uppercase tracking-wide border-b border-slate-800 pb-1 block">Retrieved Vector Chunks</span>
        {result.retrievedDocs.map((doc: any, idx: number) => (
          <div 
            key={idx} 
            id={`source-inspector-${doc.source}`}
            className={`p-3 rounded-lg border transition-all ${
              highlightedSourceId === doc.source 
                ? "bg-cyan-900/20 border-cyan-500/50 shadow-[0_0_15px_rgba(6,182,212,0.15)] ring-1 ring-cyan-500/20" 
                : "bg-slate-900/40 border-slate-800/80"
            }`}
          >
            <div className="flex flex-wrap items-center justify-between mb-2 gap-2">
              <span className="text-fcb-red font-bold text-[10px] bg-fcb-red/10 border border-fcb-red/20 px-2 py-0.5 rounded uppercase tracking-wider">{doc.source}</span>
              
              <div className="flex flex-wrap gap-1.5">
                {/* Score Badges */}
                <div className="flex items-center gap-1.5 bg-emerald-500/10 border border-emerald-500/20 px-2 py-1 rounded" title="Semantic Similarity Score">
                  <span className="text-emerald-500 text-[9px] font-bold">SemSim:</span>
                  <div className="w-12 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-500" style={{ width: `${Math.round((doc.score || 0.85) * 100)}%` }} />
                  </div>
                  <span className="text-emerald-400 text-[9px]">{Math.round((doc.score || 0.85) * 100)}%</span>
                </div>
                
                <div className="flex items-center gap-1.5 bg-amber-500/10 border border-amber-500/20 px-2 py-1 rounded" title="Keyword Match Indicator">
                  <span className="text-amber-500 text-[9px] font-bold">KW Match:</span>
                  <span className="text-amber-400 text-[9px]">{(doc.score || 0.8) > 0.8 ? 'High' : 'Medium'}</span>
                </div>

                {doc.rerankScore !== undefined && (
                  <div className="flex items-center gap-1.5 bg-purple-500/10 border border-purple-500/20 px-2 py-1 rounded" title="Re-Rank Score">
                    <span className="text-purple-500 text-[9px] font-bold">Re-Rank:</span>
                    <span className="text-purple-400 text-[9px]">{doc.rerankScore.toFixed(2)}</span>
                  </div>
                )}
              </div>
            </div>
            
            <div className="text-[10px] text-slate-400 leading-relaxed bg-slate-950 p-2.5 rounded border border-slate-800/50">
              {doc.snippet}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
