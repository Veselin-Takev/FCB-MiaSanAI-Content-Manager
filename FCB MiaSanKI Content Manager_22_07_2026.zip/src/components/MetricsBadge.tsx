import React from "react";
import { useLanguage } from "../context/LanguageContext";

interface MetricsBadgeProps {
  metrics: {
    faithfulness: number;
    answerRelevance: number;
    contextRecall: number;
    contextPrecision: number;
  };
}

export const MetricsBadge: React.FC<MetricsBadgeProps> = ({ metrics }) => {
  const { language } = useLanguage();
  if (!metrics) return null;

  const healthScore = Math.round((metrics.faithfulness + metrics.answerRelevance + metrics.contextRecall + metrics.contextPrecision) / 4);
  const healthColor = healthScore >= 90 ? "emerald-400" : healthScore >= 70 ? "amber-400" : "red-500";
  const healthBgColor = healthScore >= 90 ? "bg-emerald-400 animate-pulse" : healthScore >= 70 ? "bg-amber-400" : "bg-red-500";

  return (
    <div>
      <div className="flex items-center justify-between mb-1.5">
        <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider block">
          {language === "de" ? "RAG-Evaluierungsmetriken & Health Score" : "RAG Evaluation Metrics & Health Score"}
        </span>
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-mono text-slate-400">RAG System Health:</span>
          <div className="flex items-center gap-1.5 bg-slate-950 px-2 py-1 rounded border border-slate-800">
            <div className={`w-2 h-2 rounded-full ${healthBgColor}`} />
            <span className={`text-xs font-bold text-${healthColor}`}>
              {healthScore}/100
            </span>
          </div>
        </div>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
          <span className="text-[9px] font-mono text-cyan-400 block mb-1">Faithfulness</span>
          <div className="flex items-end justify-between">
            <span className="text-sm font-bold text-white">{metrics.faithfulness}%</span>
            <div className="w-12 h-1.5 bg-slate-800 rounded-full overflow-hidden">
              <div className="h-full bg-cyan-400" style={{ width: `${metrics.faithfulness}%` }} />
            </div>
          </div>
        </div>
        <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
          <span className="text-[9px] font-mono text-cyan-400 block mb-1">Answer Relevance</span>
          <div className="flex items-end justify-between">
            <span className="text-sm font-bold text-white">{metrics.answerRelevance}%</span>
            <div className="w-12 h-1.5 bg-slate-800 rounded-full overflow-hidden">
              <div className="h-full bg-cyan-400" style={{ width: `${metrics.answerRelevance}%` }} />
            </div>
          </div>
        </div>
        <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
          <span className="text-[9px] font-mono text-cyan-400 block mb-1">Context Recall</span>
          <div className="flex items-end justify-between">
            <span className="text-sm font-bold text-white">{metrics.contextRecall}%</span>
            <div className="w-12 h-1.5 bg-slate-800 rounded-full overflow-hidden">
              <div className="h-full bg-cyan-400" style={{ width: `${metrics.contextRecall}%` }} />
            </div>
          </div>
        </div>
        <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
          <span className="text-[9px] font-mono text-cyan-400 block mb-1">Context Precision</span>
          <div className="flex items-end justify-between">
            <span className="text-sm font-bold text-white">{metrics.contextPrecision}%</span>
            <div className="w-12 h-1.5 bg-slate-800 rounded-full overflow-hidden">
              <div className="h-full bg-cyan-400" style={{ width: `${metrics.contextPrecision}%` }} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
