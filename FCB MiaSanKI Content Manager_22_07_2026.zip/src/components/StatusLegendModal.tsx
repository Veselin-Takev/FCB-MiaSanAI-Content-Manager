import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, HelpCircle, Activity } from 'lucide-react';

interface StatusLegendModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: 'en' | 'de';
}

export const StatusLegendModal: React.FC<StatusLegendModalProps> = ({ isOpen, onClose, language }) => {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          className="bg-slate-900 border border-slate-700 w-full max-w-md rounded-xl shadow-2xl overflow-hidden"
        >
          <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950">
            <div className="flex items-center gap-2">
              <HelpCircle className="w-5 h-5 text-cyan-400" />
              <h3 className="font-bold text-slate-200">
                {language === "de" ? "Status-Legende" : "Status Legend"}
              </h3>
            </div>
            <button onClick={onClose} className="p-1.5 hover:bg-slate-800 rounded-lg transition-colors">
              <X className="w-4 h-4 text-slate-500 hover:text-slate-300" />
            </button>
          </div>
          
          <div className="p-5 space-y-6 bg-slate-900">
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="mt-1">
                  <span className="inline-flex px-2 py-1 rounded text-xs uppercase font-bold bg-slate-500/20 border border-slate-500/50 text-slate-300">
                    Draft
                  </span>
                </div>
                <div className="text-sm text-slate-400 leading-snug">
                  <strong className="text-slate-300 block mb-1">
                    {language === "de" ? "In Bearbeitung" : "Work in Progress"}
                  </strong> 
                  {language === "de" 
                    ? "Verwenden Sie diesen Status beim Testen oder wenn Sie mit den Parametereinstellungen noch nicht fertig sind."
                    : "Use this when testing or when you aren't yet finished tweaking parameters."}
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <div className="mt-1">
                  <span className="inline-flex px-2 py-1 rounded text-xs uppercase font-bold bg-amber-500/20 border border-amber-500/50 text-amber-300">
                    Needs Work
                  </span>
                </div>
                <div className="text-sm text-slate-400 leading-snug">
                  <strong className="text-amber-200 block mb-1">
                    {language === "de" ? "Überprüfung ausstehend" : "Pending Review"}
                  </strong> 
                  {language === "de"
                    ? "Wird auf Presets angewendet, die vor der endgültigen Freigabe noch einmal überarbeitet werden müssen."
                    : "Applied to presets that need to be revisited before final approval."}
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <div className="mt-1">
                  <span className="inline-flex px-2 py-1 rounded text-xs uppercase font-bold bg-emerald-500/20 border border-emerald-500/50 text-emerald-300">
                    Approved
                  </span>
                </div>
                <div className="text-sm text-slate-400 leading-snug">
                  <strong className="text-emerald-200 block mb-1">
                    {language === "de" ? "Produktionsbereit" : "Production Ready"}
                  </strong> 
                  {language === "de"
                    ? "Validierte und freigegebene Presets. Sicher für den teamweiten Einsatz."
                    : "Validated and signed-off presets. Safe for team-wide use."}
                </div>
              </div>
            </div>
            
            <div className="pt-4 border-t border-slate-800/60">
              <div className="bg-cyan-950/20 border border-cyan-900/30 rounded-lg p-3 flex items-start gap-2">
                <Activity className="w-4 h-4 text-cyan-500 mt-0.5 shrink-0" />
                <p className="text-xs text-slate-400">
                  {language === "de"
                    ? "Sie können den Status in der Tabellenansicht oder über die Batch-Aktionen ändern, um den Lebenszyklus mehrerer Presets auf einmal zu verwalten."
                    : "You can change the status in the table view or via Batch Actions to manage the lifecycle of multiple presets at once."}
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
