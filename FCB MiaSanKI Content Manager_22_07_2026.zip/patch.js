const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');
const target = `               <div className="p-5 space-y-4">
                 <div className="space-y-2">`;
const replacement = `               <div className="p-5 space-y-4">
                 {smartCollectionTemplates.length > 0 && (
                   <div className="space-y-2 pb-2 border-b border-slate-800/50">
                     <label className="block text-xs font-medium text-fuchsia-400">
                       {language === "de" ? "Aus Template laden" : "Load from Template"}
                     </label>
                     <select
                       onChange={(e) => {
                         if (!e.target.value) return;
                         const tpl = smartCollectionTemplates.find(t => t.name === e.target.value);
                         if (tpl) {
                           setSmartCollectionForm(prev => ({
                             ...prev,
                             filters: { ...tpl.filters }
                           }));
                         }
                         e.target.value = "";
                       }}
                       className="w-full bg-slate-950 border border-fuchsia-900/30 rounded-lg p-2 text-sm text-fuchsia-100 focus:outline-none focus:border-fuchsia-500/50"
                     >
                       <option value="">{language === "de" ? "-- Template wählen --" : "-- Select Template --"}</option>
                       {smartCollectionTemplates.map(tpl => (
                         <option key={tpl.name} value={tpl.name}>{tpl.name}</option>
                       ))}
                     </select>
                   </div>
                 )}
                 <div className="space-y-2">`;
code = code.replace(target, replacement);
fs.writeFileSync('src/App.tsx', code);
