import re

with open("src/App.tsx", "r") as f:
    content = f.read()

target = "{renderFolderNode(sidebarRootNode, 0)}"
replacement = "{renderSidebarFolderNode(sidebarRootNode, 0)}"

if target in content:
    content = content.replace(target, replacement)
    with open("src/App.tsx", "w") as f:
        f.write(content)
    print("Replaced successfully")
else:
    print("Target not found")
