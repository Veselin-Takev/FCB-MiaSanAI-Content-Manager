const fs = require('fs');
const code = fs.readFileSync('src/App.tsx', 'utf8');
const lines = code.split('\n');
const start = lines.findIndex(l => l.includes('const renderSidebarFolderNode ='));
const end = lines.findIndex((l, i) => i > start && l.trim() === '};');
console.log(lines.slice(start, start+150).join('\n'));
