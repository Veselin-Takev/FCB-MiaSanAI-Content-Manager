const fs = require('fs');
let code = fs.readFileSync('src/components/DashboardOverview.tsx', 'utf8');

// Add jsPDF import
code = code.replace(/import \{ TableauDashboard \} from "\.\/TableauDashboard";/, `import { TableauDashboard } from "./TableauDashboard";\nimport { jsPDF } from "jspdf";`);

// Add handleExportPDF
const handleExportPDF = `  const handleExportPDF = () => {
    const doc = new jsPDF();
    let yPos = 20;
    
    // Header
    doc.setFontSize(22);
    doc.setTextColor(220, 5, 45); // FCB Red
    doc.text("MiaSanAI - Dashboard Export", 14, yPos);
    
    yPos += 10;
    doc.setFontSize(10);
    doc.setTextColor(100, 100, 100);
    doc.text(\`Generated: \${new Date().toLocaleString()}\`, 14, yPos);
    
    yPos += 15;
    doc.setFontSize(16);
    doc.setTextColor(0, 0, 0);
    doc.text("Current Telemetry:", 14, yPos);
    yPos += 8;
    
    // Telemetry
    doc.setFontSize(11);
    doc.setTextColor(50, 50, 50);
    latestStats.forEach(stat => {
      doc.text(\`\${stat.name}: \${stat.value} (\${stat.change})\`, 14, yPos);
      yPos += 6;
    });
    
    yPos += 10;
    doc.setFontSize(16);
    doc.setTextColor(0, 0, 0);
    doc.text("Pipeline Logs:", 14, yPos);
    yPos += 8;
    
    // Logs
    doc.setFontSize(9);
    const reversedLogs = [...logs].reverse();
    reversedLogs.forEach(log => {
      if (yPos > 270) {
        doc.addPage();
        yPos = 20;
      }
      
      doc.setFont("helvetica", "bold");
      doc.setTextColor(0, 0, 0);
      doc.text(\`[\${log.timestamp}] \${log.level} - \${log.source}\`, 14, yPos);
      yPos += 5;
      
      doc.setFont("helvetica", "normal");
      doc.setTextColor(80, 80, 80);
      const splitMessage = doc.splitTextToSize(log.message, 180);
      doc.text(splitMessage, 14, yPos);
      yPos += (splitMessage.length * 5) + 5;
    });
    
    doc.save(\`miasanai_dashboard_summary_\${new Date().toISOString().slice(0, 10)}.pdf\`);
    
    onAddLog({
      id: \\\`pdf-export-\\\${Date.now()}\\\`,
      timestamp: new Date().toLocaleTimeString(),
      level: "SUCCESS",
      source: "Exporter",
      message: "Exported dashboard telemetry and pipeline logs to PDF successfully."
    });
  };\n`;

code = code.replace(/  const handleExportCSV = \(\) => \{/, handleExportPDF + '\n  const handleExportCSV = () => {');

const btnHTML = `          <button 
            onClick={handleExportPDF}
            className="bg-fcb-red hover:bg-fcb-red/90 text-white text-xs font-semibold px-3 py-1.5 rounded-lg border border-red-700 transition flex items-center gap-1 cursor-pointer"
            id="export-dashboard-pdf-btn"
          >
            <Download className="h-3.5 w-3.5" /> Export Dashboard Data
          </button>
        </div>
      </div>`;

code = code.replace(/<\/div>\n\s*<\/div>\n\n\s*\{\/\* Stats Cards \*\/\}/, btnHTML + '\n\n      {/* Stats Cards */}');

fs.writeFileSync('src/components/DashboardOverview.tsx', code);
console.log("Patched DashboardOverview");
