const fs = require('fs');
let code = fs.readFileSync('src/components/CategoryManager.tsx', 'utf8');

// Ensure CornerDownRight is imported
if (!code.includes('CornerDownRight')) {
  code = code.replace(/import {([^}]+)} from "lucide-react";/, (match, p1) => {
    return `import {${p1}, CornerDownRight} from "lucide-react";`;
  });
}

const oldRenderNode = `          {node.children.length > 0 ? (
            <button 
              onClick={() => toggleExpand(node.path)}
              className="p-0.5 hover:bg-slate-700 rounded text-slate-400 transition-colors z-10 bg-[#0c0c0f] group-hover:bg-transparent"
            >
              {expandedPaths.has(node.path) ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
            </button>
          ) : (
            <div className="w-4.5 flex justify-center items-center h-full">
               <div className="w-1 h-1 rounded-full bg-slate-700" />
            </div>
          )}`;

const newRenderNode = `          {node.children.length > 0 ? (
            <button 
              onClick={() => toggleExpand(node.path)}
              className="p-0.5 hover:bg-slate-700 rounded text-slate-400 transition-colors z-10 bg-slate-900/50 group-hover:bg-transparent"
            >
              {expandedPaths.has(node.path) ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
            </button>
          ) : (
            <div className="w-4.5 flex justify-center items-center h-full opacity-40">
               <CornerDownRight className="w-3.5 h-3.5 text-slate-500" />
            </div>
          )}`;

code = code.replace(oldRenderNode, newRenderNode);

// Let's also adjust the left padding slightly
code = code.replace(
  'className="ml-4 pl-3 border-l border-slate-800/60 flex flex-col mt-0.5"',
  'className="ml-4 pl-2 border-l border-slate-700/50 flex flex-col mt-0.5 gap-0.5"'
);

fs.writeFileSync('src/components/CategoryManager.tsx', code);
console.log("Patched renderNode with CornerDownRight!");
