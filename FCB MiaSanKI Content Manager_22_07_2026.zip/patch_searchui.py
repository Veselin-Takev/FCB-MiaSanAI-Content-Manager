import re

with open("src/App.tsx", "r") as f:
    content = f.read()

target = """                                          <div className="relative" id="export-presets-search-container">
                                            <input
                                              type="text"
                                              value={exportPresetSearchQuery}
                                              onChange={(e) => setExportPresetSearchQuery(e.target.value)}
                                              placeholder={language === "de" ? "Suchen nach Name, Kategorie oder Metadaten (z.B. comp, dry, fade, gate, 12)..." : "Search presets by name, category or metadata (e.g., comp, dry, fade, gate, 12)..."}
                                              className="w-full bg-slate-950 border border-slate-900 rounded pl-7 pr-6 py-1 text-[8.5px] font-mono text-white placeholder:text-slate-600 focus:outline-none focus:border-cyan-500 transition"
                                            />
                                            <Search className="absolute left-2 top-1.5 h-3.5 w-3.5 text-slate-600 pointer-events-none" />
                                            {exportPresetSearchQuery && (
                                              <button
                                                onClick={() => setExportPresetSearchQuery("")}
                                                className="absolute right-1.5 top-1.5 text-slate-500 hover:text-white hover:bg-slate-900 p-0.5 rounded cursor-pointer transition"
                                              >
                                                <X className="h-3 w-3" />
                                              </button>
                                            )}
                                          </div>"""

replacement = """                                          <div className="flex flex-col gap-1">
                                            <div className="relative" id="export-presets-search-container">
                                              <input
                                                type="text"
                                                value={exportPresetSearchQuery}
                                                onChange={(e) => setExportPresetSearchQuery(e.target.value)}
                                                placeholder={language === "de" ? "Suchen nach Name, Kategorie oder Metadaten (z.B. comp, dry, fade, gate, 12)..." : "Search presets by name, category or metadata (e.g., comp, dry, fade, gate, 12)..."}
                                                className="w-full bg-slate-950 border border-slate-900 rounded pl-7 pr-6 py-1 text-[8.5px] font-mono text-white placeholder:text-slate-600 focus:outline-none focus:border-cyan-500 transition"
                                              />
                                              <Search className="absolute left-2 top-1.5 h-3.5 w-3.5 text-slate-600 pointer-events-none" />
                                              {exportPresetSearchQuery && (
                                                <button
                                                  onClick={() => setExportPresetSearchQuery("")}
                                                  className="absolute right-1.5 top-1.5 text-slate-500 hover:text-white hover:bg-slate-900 p-0.5 rounded cursor-pointer transition"
                                                >
                                                  <X className="h-3 w-3" />
                                                </button>
                                              )}
                                            </div>
                                            <div className="relative" id="export-presets-deep-search-container">
                                              <input
                                                type="text"
                                                value={presetDeepSearchQuery}
                                                onChange={(e) => setPresetDeepSearchQuery(e.target.value)}
                                                placeholder={language === "de" ? "Tiefensuche (Name, Beschreibung, Notizen)..." : "Deep Search (Name, Description, Notes)..."}
                                                className="w-full bg-slate-950/60 border border-slate-900/80 rounded pl-7 pr-6 py-1 text-[8.5px] font-mono text-cyan-100 placeholder:text-cyan-700/50 focus:outline-none focus:border-cyan-500/80 transition"
                                              />
                                              <Search className="absolute left-2 top-1.5 h-3.5 w-3.5 text-cyan-700/50 pointer-events-none" />
                                              {presetDeepSearchQuery && (
                                                <button
                                                  onClick={() => setPresetDeepSearchQuery("")}
                                                  className="absolute right-1.5 top-1.5 text-cyan-600/50 hover:text-cyan-300 hover:bg-slate-900 p-0.5 rounded cursor-pointer transition"
                                                >
                                                  <X className="h-3 w-3" />
                                                </button>
                                              )}
                                            </div>
                                          </div>"""

if target in content:
    content = content.replace(target, replacement)
    with open("src/App.tsx", "w") as f:
        f.write(content)
    print("Replaced successfully")
else:
    print("Target not found")
