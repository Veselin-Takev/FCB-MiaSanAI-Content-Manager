const fs = require('fs');
let code = fs.readFileSync('src/components/DashboardOverview.tsx', 'utf8');

const latestStatsCode = `  const latestStats = [
    { id: "stat1", name: "Total Fan Reach", value: "1.42M", change: "+14.2% vs last week", icon: Users, color: "text-cyan-400" },
    { id: "stat2", name: "Active AI Automations", value: "24 Rules", change: "99.8% System Uptime", icon: Zap, color: "text-fcb-red" },
    { id: "stat3", name: "Avg Engagement Rate", value: "8.43%", change: "+2.1% Industry High", icon: TrendingUp, color: "text-amber-400" },
    { id: "stat4", name: "Conversations Active", value: "4,102 DMs", change: "Powered by MiaSanAI", icon: Sparkles, color: "text-purple-400" }
  ];\n`;

code = code.replace(latestStatsCode, "");
code = code.replace(/  const handleExportPDF = \(\) => \{/, latestStatsCode + "\n  const handleExportPDF = () => {");

fs.writeFileSync('src/components/DashboardOverview.tsx', code);
console.log("Moved latestStats");
