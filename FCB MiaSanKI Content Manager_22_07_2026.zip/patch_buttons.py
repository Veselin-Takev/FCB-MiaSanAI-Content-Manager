import re

with open("src/App.tsx", "r") as f:
    content = f.read()

content = content.replace('"+ ROOT CATEGORY"', '"Add New Root Category"')
content = content.replace('"+ HAUPTKATEGORIE"', '"+ NEUE HAUPTKATEGORIE"')

content = content.replace('"Create Root Category"', '"Add New Root Category"')
content = content.replace('"Neue Hauptkategorie erstellen"', '"Neue Hauptkategorie hinzufügen"')

with open("src/App.tsx", "w") as f:
    f.write(content)
