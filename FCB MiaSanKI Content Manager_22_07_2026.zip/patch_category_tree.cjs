const fs = require('fs');
let code = fs.readFileSync('src/components/CategoryManager.tsx', 'utf8');

const oldRenderNode = `  const renderNode = (node: TreeNode, level: number) => {
    const isEditing = editingPath === node.path;
    const isDragTarget = draggedPath && draggedPath !== node.path && !node.path.startsWith(draggedPath + "/");

    return (
      <div key={node.path} className="w-full">
        <div 
          className={\`flex items-center gap-2 py-1.5 px-2 rounded-lg group transition-colors
            \${isDragTarget ? "hover:bg-cyan-900/30" : "hover:bg-slate-800/50"}\`}
          style={{ paddingLeft: \`\${level * 16 + 8}px\` }}
          draggable={node.path !== ""}
          onDragStart={(e) => {
            e.stopPropagation();
            setDraggedPath(node.path);
          }}
          onDragOver={(e) => {
            e.preventDefault();
            e.stopPropagation();
          }}
          onDrop={(e) => {
            e.preventDefault();
            e.stopPropagation();
            if (draggedPath && draggedPath !== node.path) {
              handleMove(draggedPath, node.path);
            }
            setDraggedPath(null);
          }}
          onDragEnd={() => setDraggedPath(null)}
        >
          {node.children.length > 0 ? (
            <button 
              onClick={() => toggleExpand(node.path)}
              className="p-0.5 hover:bg-slate-700 rounded text-slate-400"
            >
              {expandedPaths.has(node.path) ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
            </button>
          ) : (
            <div className="w-4.5" /> // spacer
          )}
          
          <Folder className="w-4 h-4 text-cyan-500" />
          
          {isEditing && node.path !== "" ? (
            <div className="flex items-center gap-1 flex-1">
              <input
                autoFocus
                value={editValue}
                onChange={e => setEditValue(e.target.value)}
                onKeyDown={e => {
                  if (e.key === "Enter") handleRename(node.path, editValue);
                  if (e.key === "Escape") setEditingPath(null);
                }}
                className="bg-slate-900 border border-cyan-500 rounded px-2 py-0.5 text-xs text-white focus:outline-none w-full max-w-[200px]"
              />
              <button onClick={() => handleRename(node.path, editValue)} className="p-1 text-green-400 hover:bg-slate-700 rounded"><Check className="w-3.5 h-3.5" /></button>
              <button onClick={() => setEditingPath(null)} className="p-1 text-red-400 hover:bg-slate-700 rounded"><X className="w-3.5 h-3.5" /></button>
            </div>
          ) : (
            <span className="text-xs text-slate-200 flex-1 select-none font-medium">
              {node.name || "Root"}
            </span>
          )}

          {node.path !== "" && !isEditing && (
            <div className="opacity-0 group-hover:opacity-100 flex items-center gap-1">
              <button
                onClick={() => {
                  setEditingPath(node.path);
                  setEditValue(node.name);
                }}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-700 rounded transition-colors"
                title={language === "de" ? "Umbenennen" : "Rename"}
              >
                <Edit2 className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
        
        {expandedPaths.has(node.path) && (
          <div>
            {node.children.map(child => renderNode(child, level + 1))}
          </div>
        )}
      </div>
    );
  };`;

const newRenderNode = `  const renderNode = (node: TreeNode, level: number) => {
    const isEditing = editingPath === node.path;
    const isDragTarget = draggedPath && draggedPath !== node.path && !node.path.startsWith(draggedPath + "/");

    return (
      <div key={node.path} className="w-full">
        <div 
          className={\`flex items-center gap-1.5 py-1.5 px-2 rounded-lg group transition-colors relative
            \${isDragTarget ? "bg-cyan-900/30 ring-1 ring-cyan-500/50" : "hover:bg-slate-800/40"}\`}
          draggable={node.path !== ""}
          onDragStart={(e) => {
            e.stopPropagation();
            setDraggedPath(node.path);
          }}
          onDragOver={(e) => {
            e.preventDefault();
            e.stopPropagation();
          }}
          onDrop={(e) => {
            e.preventDefault();
            e.stopPropagation();
            if (draggedPath && draggedPath !== node.path) {
              handleMove(draggedPath, node.path);
            }
            setDraggedPath(null);
          }}
          onDragEnd={() => setDraggedPath(null)}
        >
          {/* Depth indicators for the row itself aren't strictly necessary when using left border on children, 
              but we can add a visual connecting line for the item if desired. 
              Using left border on the children container provides a clean modern look. */}
              
          {node.children.length > 0 ? (
            <button 
              onClick={() => toggleExpand(node.path)}
              className="p-0.5 hover:bg-slate-700 rounded text-slate-400 transition-colors z-10 bg-[#0c0c0f] group-hover:bg-transparent"
            >
              {expandedPaths.has(node.path) ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
            </button>
          ) : (
            <div className="w-4.5 flex justify-center items-center h-full">
               <div className="w-1 h-1 rounded-full bg-slate-700" />
            </div>
          )}
          
          <Folder className={\`w-4 h-4 \${node.path === "" ? "text-amber-500" : "text-cyan-500"}\`} />
          
          {isEditing && node.path !== "" ? (
            <div className="flex items-center gap-1 flex-1">
              <input
                autoFocus
                value={editValue}
                onChange={e => setEditValue(e.target.value)}
                onKeyDown={e => {
                  if (e.key === "Enter") handleRename(node.path, editValue);
                  if (e.key === "Escape") setEditingPath(null);
                }}
                className="bg-slate-950 border border-cyan-500/50 rounded px-2 py-0.5 text-xs text-white focus:outline-none focus:border-cyan-400 w-full max-w-[200px]"
              />
              <button onClick={() => handleRename(node.path, editValue)} className="p-1 text-emerald-400 hover:bg-slate-800 rounded"><Check className="w-3.5 h-3.5" /></button>
              <button onClick={() => setEditingPath(null)} className="p-1 text-rose-400 hover:bg-slate-800 rounded"><X className="w-3.5 h-3.5" /></button>
            </div>
          ) : (
            <span className={\`text-xs flex-1 select-none font-medium truncate \${node.path === "" ? "text-amber-400" : "text-slate-200"}\`}>
              {node.name || "Root"}
            </span>
          )}

          {node.path !== "" && !isEditing && (
            <div className="opacity-0 group-hover:opacity-100 flex items-center gap-1">
              <button
                onClick={() => {
                  setEditingPath(node.path);
                  setEditValue(node.name);
                }}
                className="p-1.5 text-slate-400 hover:text-cyan-400 hover:bg-slate-800 rounded transition-colors"
                title={language === "de" ? "Umbenennen" : "Rename"}
              >
                <Edit2 className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
        
        {expandedPaths.has(node.path) && node.children.length > 0 && (
          <div className="ml-4 pl-3 border-l border-slate-800/60 flex flex-col mt-0.5">
            {node.children.map(child => renderNode(child, level + 1))}
          </div>
        )}
      </div>
    );
  };`;

// replace
if (code.includes('className={`flex items-center gap-2 py-1.5 px-2 rounded-lg group transition-colors')) {
  code = code.replace(oldRenderNode, newRenderNode);
  fs.writeFileSync('src/components/CategoryManager.tsx', code);
  console.log("Patched renderNode!");
} else {
  console.log("Could not find exact old block, please check.");
}
