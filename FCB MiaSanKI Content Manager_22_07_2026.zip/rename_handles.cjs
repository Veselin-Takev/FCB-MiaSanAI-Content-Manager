const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

code = code.replace(/const handleUndo = \(\) => \{/g, "const handleBulkUndo = () => {");
code = code.replace(/const handleRedo = \(\) => \{/g, "const handleBulkRedo = () => {");

code = code.replace(/onClick=\{handleUndo\}/g, "onClick={handleBulkUndo}");
code = code.replace(/onClick=\{handleRedo\}/g, "onClick={handleBulkRedo}");

// Also, let's fix the first replacement that created duplicate handleUndo, wait there's no duplicate handleUndo from my patch, 
// just conflicts with the existing handleUndo. But I did `const handleUndo = () => {` which replaced `const handleUndoLastBulkOperation = () => {`.
// Let's just run this and it'll fix my declarations.
// Wait, the existing handleUndo is `const handleUndo = React.useCallback(() => {`.
// So replacing `const handleUndo = () => {` will only replace MINE!

fs.writeFileSync('src/App.tsx', code);
console.log("Renamed handles");
