const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

code = code.replace(/const \[bulkUndoStack, setBulkUndoStack\] = useState<\{ id: string; description: string; descriptionDe: string; presets: any\[\] \}\[\]>\(\[\]\);/g, 
  `const [undoStack, setUndoStack] = useState<{ id: string; description: string; descriptionDe: string; presets: any[] }[]>([]);
  const [redoStack, setRedoStack] = useState<{ id: string; description: string; descriptionDe: string; presets: any[] }[]>([]);`);

code = code.replace(/const pushToBulkUndoStack = \(desc: string, descDe: string\) => \{\n\s*setBulkUndoStack\(prev => \[\.\.\.prev, \{\n\s*id: `undo-\$\{Date\.now\(\)\}`,\n\s*description: desc,\n\s*descriptionDe: descDe,\n\s*presets: JSON\.parse\(JSON\.stringify\(exportPresets\)\)\n\s*\}\]\.slice\(-10\)\);\n\s*\};/g,
  `const pushToUndoStack = (desc: string, descDe: string) => {
    setUndoStack(prev => [...prev, {
      id: \`undo-\${Date.now()}\`,
      description: desc,
      descriptionDe: descDe,
      presets: JSON.parse(JSON.stringify(exportPresets))
    }].slice(-20));
    setRedoStack([]);
  };`);

code = code.replace(/pushToBulkUndoStack/g, "pushToUndoStack");

code = code.replace(/const handleUndoLastBulkOperation = \(\) => \{\n\s*if \(bulkUndoStack\.length === 0\) return;\n\s*const lastOp = bulkUndoStack\[bulkUndoStack\.length - 1\];\n\s*setExportPresets\(lastOp\.presets\);\n\s*try \{\n\s*localStorage\.setItem\("fcb_miasanai_export_presets", JSON\.stringify\(lastOp\.presets\)\);\n\s*\} catch \(e\) \{\n\s*console\.error\(e\);\n\s*\}\n\s*setBulkUndoStack\(prev => prev\.slice\(0, -1\)\);\n\s*handleAddLog\(\{\n\s*id: `undo-applied-\$\{Date\.now\(\)\}`,\n\s*timestamp: new Date\(\)\.toLocaleTimeString\(\),\n\s*source: "Preset Manager",\n\s*level: "SUCCESS",\n\s*message: language === "de"\n\s*\? `Letzte Massenbearbeitung rückgängig gemacht: \$\{lastOp\.descriptionDe\}`\n\s*: `Undid last batch operation: \$\{lastOp\.description\}`\n\s*\}\);\n\s*\};/g,
  `const handleUndo = () => {
    if (undoStack.length === 0) return;
    const lastOp = undoStack[undoStack.length - 1];
    setRedoStack(prev => [...prev, {
      id: \`redo-\${Date.now()}\`,
      description: lastOp.description,
      descriptionDe: lastOp.descriptionDe,
      presets: JSON.parse(JSON.stringify(exportPresets))
    }].slice(-20));
    setExportPresets(lastOp.presets);
    try {
      localStorage.setItem("fcb_miasanai_export_presets", JSON.stringify(lastOp.presets));
    } catch (e) {
      console.error(e);
    }
    setUndoStack(prev => prev.slice(0, -1));
    handleAddLog({
      id: \`undo-applied-\${Date.now()}\`,
      timestamp: new Date().toLocaleTimeString(),
      source: "Preset Manager",
      level: "SUCCESS",
      message: language === "de" 
        ? \`Letzte Aktion rückgängig gemacht: \${lastOp.descriptionDe}\` 
        : \`Undid last action: \${lastOp.description}\`
    });
  };

  const handleRedo = () => {
    if (redoStack.length === 0) return;
    const lastOp = redoStack[redoStack.length - 1];
    setUndoStack(prev => [...prev, {
      id: \`undo-\${Date.now()}\`,
      description: lastOp.description,
      descriptionDe: lastOp.descriptionDe,
      presets: JSON.parse(JSON.stringify(exportPresets))
    }].slice(-20));
    setExportPresets(lastOp.presets);
    try {
      localStorage.setItem("fcb_miasanai_export_presets", JSON.stringify(lastOp.presets));
    } catch (e) {
      console.error(e);
    }
    setRedoStack(prev => prev.slice(0, -1));
    handleAddLog({
      id: \`redo-applied-\${Date.now()}\`,
      timestamp: new Date().toLocaleTimeString(),
      source: "Preset Manager",
      level: "SUCCESS",
      message: language === "de" 
        ? \`Aktion wiederhergestellt: \${lastOp.descriptionDe}\` 
        : \`Redid action: \${lastOp.description}\`
    });
  };`);

// Update UI
const uiOldStr = `                                          {bulkUndoStack.length > 0 && (
                                            <button
                                              type="button"
                                              onClick={handleUndoLastBulkOperation}
                                              className="flex items-center gap-1.5 py-1 px-2.5 bg-rose-950/20 border border-rose-900/40 hover:bg-rose-900/40 hover:border-rose-500/50 rounded transition-all cursor-pointer text-[8px] font-mono font-bold text-rose-400"
                                              title={language === "de" ? bulkUndoStack[bulkUndoStack.length - 1].descriptionDe : bulkUndoStack[bulkUndoStack.length - 1].description}
                                            >
                                              <Undo2 className="h-3 w-3 shrink-0" />
                                              {language === "de" ? "Batch Undo" : "Batch Undo"}
                                            </button>
                                          )}`;

const uiNewStr = `                                          {undoStack.length > 0 && (
                                            <button
                                              type="button"
                                              onClick={handleUndo}
                                              className="flex items-center gap-1.5 py-1 px-2.5 bg-rose-950/20 border border-rose-900/40 hover:bg-rose-900/40 hover:border-rose-500/50 rounded transition-all cursor-pointer text-[8px] font-mono font-bold text-rose-400"
                                              title={language === "de" ? undoStack[undoStack.length - 1].descriptionDe : undoStack[undoStack.length - 1].description}
                                            >
                                              <Undo2 className="h-3 w-3 shrink-0" />
                                              {language === "de" ? "Undo" : "Undo"}
                                            </button>
                                          )}
                                          {redoStack.length > 0 && (
                                            <button
                                              type="button"
                                              onClick={handleRedo}
                                              className="flex items-center gap-1.5 py-1 px-2.5 bg-cyan-950/20 border border-cyan-900/40 hover:bg-cyan-900/40 hover:border-cyan-500/50 rounded transition-all cursor-pointer text-[8px] font-mono font-bold text-cyan-400"
                                              title={language === "de" ? redoStack[redoStack.length - 1].descriptionDe : redoStack[redoStack.length - 1].description}
                                            >
                                              <Redo2 className="h-3 w-3 shrink-0" />
                                              {language === "de" ? "Redo" : "Redo"}
                                            </button>
                                          )}`;

code = code.replace(uiOldStr, uiNewStr);

fs.writeFileSync('src/App.tsx', code);
console.log("Patched!");
