const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

// For Status Update (line 11425)
const statusUpdateOld = `                                                              setBatchStatusHistoryLog(prev => [newLog, ...prev]);
                                                              }
                                                              setExportPresets(updated);
                                                              setPresetSaveError(language === "de" ? \`Status '\${newStatus}' angewendet!\` : \`Status '\${newStatus}' applied!\`);`;

const statusUpdateNew = `                                                              setBatchStatusHistoryLog(prev => [newLog, ...prev]);
                                                              }
                                                              pushToUndoStack(
                                                                \`Batch updated status to '\${newStatus}' for \${affectedPresets.length} presets\`,
                                                                \`Status '\${newStatus}' für \${affectedPresets.length} Presets massenweise aktualisiert\`
                                                              );
                                                              setExportPresets(updated);
                                                              setPresetSaveError(language === "de" ? \`Status '\${newStatus}' angewendet!\` : \`Status '\${newStatus}' applied!\`);`;

// For Rename Update (line ~11480)
const renameUpdateOld = `                                                                  return { ...p, name: updatedName };
                                                                });
                                                                setExportPresets(updated);
                                                              }
                                                            }`;

const renameUpdateNew = `                                                                  return { ...p, name: updatedName };
                                                                });
                                                                pushToUndoStack(
                                                                  \`Batch renamed \${indexCounter - 1} presets\`,
                                                                  \`\${indexCounter - 1} Presets massenweise umbenannt\`
                                                                );
                                                                setExportPresets(updated);
                                                              }
                                                            }`;

// For Toggle Highlight (line ~11545)
const toggleHighlightOld = `                                                                return { ...p, isHighlighted: !p.isHighlighted };
                                                              });
                                                              setExportPresets(updated);
                                                            }
                                                          }}`;
const toggleHighlightNew = `                                                                return { ...p, isHighlighted: !p.isHighlighted };
                                                              });
                                                              pushToUndoStack(
                                                                \`Batch toggled highlight for \${batchSelectedPresets.length} presets\`,
                                                                \`Highlight für \${batchSelectedPresets.length} Presets umgeschaltet\`
                                                              );
                                                              setExportPresets(updated);
                                                            }
                                                          }}`;

code = code.replace(statusUpdateOld, statusUpdateNew);
code = code.replace(renameUpdateOld, renameUpdateNew);
code = code.replace(toggleHighlightOld, toggleHighlightNew);

// Add Undo/Redo Buttons to the Batch Panel if missing
// Let's insert them right after `visibleSelectedCount > 0 && (` inside the batch panel
// We'll see if we can locate:
//                                                         )}
//                                                         {/* Status Update History Button */}
const batchButtonsOld = `                                                          </div>
                                                        )}
                                                        {/* Status Update History Button */}`;

const batchButtonsNew = `                                                          </div>
                                                        )}
                                                        <div className="flex items-center gap-0.5 ml-1 mr-1">
                                                          <button
                                                            type="button"
                                                            onClick={handleBulkUndo}
                                                            disabled={historyState.past.length === 0}
                                                            className={\`p-1 rounded border flex items-center justify-center transition-colors \${historyState.past.length > 0 ? 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700 hover:text-white' : 'bg-transparent border-transparent text-slate-600 opacity-50 cursor-not-allowed'}\`}
                                                            title={language === "de" ? "Rückgängig (Strg+Z)" : "Undo change (Ctrl+Z)"}
                                                          >
                                                            <Undo className="h-3 w-3" />
                                                          </button>
                                                          <button
                                                            type="button"
                                                            onClick={handleBulkRedo}
                                                            disabled={historyState.future.length === 0}
                                                            className={\`p-1 rounded border flex items-center justify-center transition-colors \${historyState.future.length > 0 ? 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700 hover:text-white' : 'bg-transparent border-transparent text-slate-600 opacity-50 cursor-not-allowed'}\`}
                                                            title={language === "de" ? "Wiederholen (Strg+Y)" : "Redo change (Ctrl+Y)"}
                                                          >
                                                            <Redo className="h-3 w-3" />
                                                          </button>
                                                        </div>
                                                        {/* Status Update History Button */}`;

if (code.includes(batchButtonsOld)) {
  code = code.replace(batchButtonsOld, batchButtonsNew);
  console.log("Patched Batch panel buttons!");
} else {
  console.log("Could not find batchButtonsOld");
}

fs.writeFileSync('src/App.tsx', code);
console.log("Finished patching App.tsx");
