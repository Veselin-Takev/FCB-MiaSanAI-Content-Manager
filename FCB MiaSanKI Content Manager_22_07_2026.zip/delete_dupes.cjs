const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const regex = /const handleBulkUndo = \(\) => \{\n\s*if \(undoStack\.length === 0\) return;[\s\S]*?\}\);\n\s*\};\n/g;
code = code.replace(regex, "");

const regex2 = /const handleBulkRedo = \(\) => \{\n\s*if \(redoStack\.length === 0\) return;[\s\S]*?\}\);\n\s*\};\n/g;
code = code.replace(regex2, "");

fs.writeFileSync('src/App.tsx', code);
console.log("Deleted old versions");
