import re

with open("src/App.tsx", "r") as f:
    content = f.read()

target_start = """              {/* Detailed visualization panel */}"""
target_end = """              )}
            </div>
          );
        })()}"""

# We'll split the content, replace the middle part.
idx_start = content.find(target_start)
idx_end = content.find(target_end) + len(target_end)

if idx_start == -1 or idx_end == -1:
    print("Could not find boundaries")
    exit(1)

new_content = """              <div className="flex items-center justify-start gap-2 mb-0.5 border-b border-slate-800/80 pb-1 pointer-events-auto shrink-0 mt-0.5">
                <button 
                  type="button" 
                  onClick={(e) => { e.stopPropagation(); setExpandedPresetTab("details"); }}
                  className={`text-[6px] font-bold uppercase transition-colors px-1.5 py-0.5 rounded ${expandedPresetTab === "details" ? "bg-cyan-500/10 text-cyan-400 border border-cyan-500/30" : "text-slate-500 hover:text-slate-300 hover:bg-slate-900 border border-transparent"}`}
                >
                  {language === "de" ? "Details" : "Details"}
                </button>
                <button 
                  type="button" 
                  onClick={(e) => { e.stopPropagation(); setExpandedPresetTab("audit"); }}
                  className={`text-[6px] font-bold uppercase transition-colors px-1.5 py-0.5 rounded ${expandedPresetTab === "audit" ? "bg-cyan-500/10 text-cyan-400 border border-cyan-500/30" : "text-slate-500 hover:text-slate-300 hover:bg-slate-900 border border-transparent"}`}
                >
                  {language === "de" ? "Audit Log" : "Audit Log"}
                </button>
              </div>

              {expandedPresetTab === "details" ? (
                <>
                  {/* Detailed visualization panel */}
                  <div className="relative w-full h-[55px] bg-slate-950 rounded border border-slate-900/80 overflow-hidden flex flex-col justify-between p-1 mt-0.5">
                    {/* SVG canvas */}
                    <svg viewBox="0 0 100 55" preserveAspectRatio="none" className="absolute inset-0 w-full h-full">
                      <defs>
                        <linearGradient id={`fadeInGrad-${pId}`} x1="0" y1="0" x2="1" y2="0">
                          <stop offset="0%" stopColor="#06b6d4" />
                          <stop offset="100%" stopColor="#06b6d4" stopOpacity="0" />
                        </linearGradient>
                        <linearGradient id={`fadeOutGrad-${pId}`} x1="0" y1="0" x2="1" y2="0">
                          <stop offset="0%" stopColor="#fb7185" stopOpacity="0" />
                          <stop offset="100%" stopColor="#fb7185" />
                        </linearGradient>
                        <linearGradient id={`waveGrad-${pId}`} x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor={preset.category.startsWith("Technical") ? "#8b5cf6" : "#10b981"} stopOpacity="0.4" />
                          <stop offset="100%" stopColor={preset.category.startsWith("Technical") ? "#8b5cf6" : "#10b981"} stopOpacity="0.02" />
                        </linearGradient>
                      </defs>
                      {/* Grid Lines */}
                      <line x1="0" y1="13.75" x2="100" y2="13.75" stroke="rgba(255,255,255,0.03)" strokeWidth="0.5" />
                      <line x1="0" y1="27.5" x2="100" y2="27.5" stroke="rgba(255,255,255,0.03)" strokeWidth="0.5" />
                      <line x1="0" y1="41.25" x2="100" y2="41.25" stroke="rgba(255,255,255,0.03)" strokeWidth="0.5" />
                      <line x1="25" y1="0" x2="25" y2="55" stroke="rgba(255,255,255,0.03)" strokeWidth="0.5" />
                      <line x1="50" y1="0" x2="50" y2="55" stroke="rgba(255,255,255,0.03)" strokeWidth="0.5" />
                      <line x1="75" y1="0" x2="75" y2="55" stroke="rgba(255,255,255,0.03)" strokeWidth="0.5" />
                      
                      {/* Fade-In Envelope Shading */}
                      {fadeInWidth > 0 && (
                        <rect x="0" y="0" width={fadeInWidth} height="55" fill={`url(#fadeInGrad-${pId})`} opacity="0.12" />
                      )}
                      
                      {/* Fade-Out Envelope Shading */}
                      {fadeOutWidth > 0 && (
                        <rect x={100 - fadeOutWidth} y="0" width={fadeOutWidth} height="55" fill={`url(#fadeOutGrad-${pId})`} opacity="0.12" />
                      )}
                      
                      {/* Raw uncompressed wave (Subtle background path) */}
                      {hasCompression && (
                        <path d={rawAreaPath} fill="rgba(255, 255, 255, 0.015)" stroke="rgba(255, 255, 255, 0.08)" strokeWidth="0.5" strokeDasharray="1,1" />
                      )}
                      
                      {/* Final processed wave path & area */}
                      <path d={finalAreaPath} fill={`url(#waveGrad-${pId})`} />
                      <path d={`M ${finalPathPoints}`} fill="none" stroke={preset.category.startsWith("Technical") ? "#a78bfa" : "#34d399"} strokeWidth="0.8" />
                      
                      {/* Compression threshold line */}
                      {hasCompression && thresholdY !== null && (
                        <line x1="0" y1={thresholdY * 0.5 + 5} x2="100" y2={thresholdY * 0.5 + 5} stroke="#f43f5e" strokeWidth="0.65" strokeDasharray="2,2" opacity="0.7" />
                      )}
                    </svg>

                    {/* Compression Indicator Label */}
                    {hasCompression && thresholdY !== null && (
                      <div className="absolute right-1 top-[2px] bg-slate-950/80 px-1 py-[1.5px] rounded border border-rose-500/20 text-[6px] font-mono text-rose-400 scale-[0.85] origin-top-right z-20">
                        {language === "de" ? "Schwelle" : "Thresh"}: {midThresh} dB
                      </div>
                    )}
                    
                    {/* Left/Right envelope marks */}
                    <div className="absolute bottom-0.5 left-1 flex items-center gap-1.5 z-20 scale-[0.8] origin-bottom-left">
                      {fadeIn > 0 && (
                        <span className="text-cyan-400 bg-cyan-950/40 border border-cyan-500/20 px-1 py-[0.5px] rounded text-[6px]">
                          In: {fadeIn}s
                        </span>
                      )}
                      {fadeOut > 0 && (
                        <span className="text-rose-400 bg-rose-950/40 border border-rose-500/20 px-1 py-[0.5px] rounded text-[6px]">
                          Out: {fadeOut}s
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Summary metadata row */}
                  <div className="grid grid-cols-2 gap-1 text-[6.5px] bg-slate-950/50 p-1 rounded border border-slate-900/60 leading-none">
                    <div className="flex flex-col gap-0.5">
                      <span className="text-slate-500">{language === "de" ? "KATEGORIE:" : "CATEGORY:"}</span>
                      <span className="text-slate-300 truncate font-semibold">{preset.translatedCategory || preset.category}</span>
                    </div>
                    <div className="flex flex-col gap-0.5 text-right">
                      <span className="text-slate-500">{language === "de" ? "KOMPRESSION:" : "COMPRESSION:"}</span>
                      <span className="text-slate-300 font-semibold">
                        {hasCompression ? `Ratio ${ratio}:1 • Makeup +${makeup}dB` : (language === "de" ? "Umgangen" : "Bypassed")}
                      </span>
                    </div>
                  </div>

                  {/* Editable Description / Info snippet */}
                  <div className="flex flex-col gap-0.5 mt-0.5 pointer-events-auto shrink-0" onClick={e => e.stopPropagation()}>
                    <span className="text-[6px] font-bold text-slate-500">{language === "de" ? "BESCHREIBUNG:" : "DESCRIPTION:"}</span>
                    <input
                      type="text"
                      value={preset.description || ""}
                      onChange={(e) => {
                        const val = e.target.value;
                        if (preset.id === "live-preview-mock-id") {
                          setNewPresetDescription(val);
                        } else {
                          const updated = exportPresets.map(p => p.id === preset.id ? { ...p, description: val, pendingSync: true } : p);
                          setExportPresets(updated);
                        }
                      }}
                      onBlur={() => {
                        if (preset.id !== "live-preview-mock-id") {
                          try {
                            localStorage.setItem("fcb_miasanai_export_presets", JSON.stringify(exportPresets));
                          } catch (err) {
                            console.error(err);
                          }
                        }
                      }}
                      placeholder={language === "de" ? "Keine Beschreibung..." : "No description..."}
                      className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-700/50 hover:border-slate-700/50 text-slate-300 px-1.5 py-0.5 rounded text-[6.5px] font-mono outline-none transition-colors placeholder:text-slate-600/50"
                    />
                  </div>

                  {/* Editable Internal Notes */}
                  <div className="flex flex-col gap-0.5 mt-0.5 pointer-events-auto shrink-0" onClick={e => e.stopPropagation()}>
                    <span className="text-[6px] font-bold text-slate-500">{language === "de" ? "INTERNE NOTIZEN:" : "INTERNAL NOTES:"}</span>
                    <input
                      type="text"
                      value={preset.notes || ""}
                      onChange={(e) => {
                        const val = e.target.value;
                        if (preset.id === "live-preview-mock-id") {
                          setNewPresetNotes(val);
                        } else {
                          const updated = exportPresets.map(p => p.id === preset.id ? { ...p, notes: val, pendingSync: true } : p);
                          setExportPresets(updated);
                        }
                      }}
                      onBlur={() => {
                        if (preset.id !== "live-preview-mock-id") {
                          try {
                            localStorage.setItem("fcb_miasanai_export_presets", JSON.stringify(exportPresets));
                          } catch (err) {
                            console.error(err);
                          }
                        }
                      }}
                      placeholder={language === "de" ? "Keine Notizen..." : "No notes..."}
                      className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-700/50 hover:border-slate-700/50 text-slate-300 px-1.5 py-0.5 rounded text-[6.5px] font-mono outline-none transition-colors placeholder:text-slate-600/50"
                    />
                  </div>

                  {/* Status Tagging Buttons Row */}
                  <div 
                    className="flex items-center justify-between gap-1 text-[6.5px] bg-slate-950/50 p-1 rounded border border-slate-900/60 leading-none pointer-events-auto shrink-0 mt-0.5" 
                    onClick={(e) => e.stopPropagation()}
                    id={`status-tagging-row-${preset.id}`}
                  >
                    <span className="text-slate-500 font-bold">{language === "de" ? "STATUS:" : "STATUS:"}</span>
                    <div className="flex gap-1 shrink-0">
                      {(["Draft", "Needs Work", "Approved"] as const).map((statusVal) => {
                        const isCurrent = preset.status === statusVal;
                        let colorClasses = "";
                        let activeColorClasses = "";
                        
                        if (statusVal === "Approved") {
                          colorClasses = "text-emerald-500 hover:text-emerald-400 bg-slate-950/40 border-slate-900/60 hover:bg-emerald-500/5 hover:border-emerald-500/20";
                          activeColorClasses = "bg-emerald-500/20 border-emerald-500/50 text-emerald-300 font-bold shadow-[0_0_8px_rgba(16,185,129,0.15)]";
                        } else if (statusVal === "Draft") {
                          colorClasses = "text-slate-400 hover:text-slate-300 bg-slate-950/40 border-slate-900/60 hover:bg-slate-800/10 hover:border-slate-700/35";
                          activeColorClasses = "bg-slate-500/20 border-slate-500/50 text-slate-200 font-bold shadow-[0_0_8px_rgba(100,116,139,0.15)]";
                        } else {
                          colorClasses = "text-amber-500 hover:text-amber-400 bg-slate-950/40 border-slate-900/60 hover:bg-amber-500/5 hover:border-amber-500/20";
                          activeColorClasses = "bg-amber-500/20 border-amber-500/50 text-amber-300 font-bold shadow-[0_0_8px_rgba(245,158,11,0.15)]";
                        }

                        const labelText = 
                          statusVal === "Approved" ? (language === "de" ? "Freigegeben" : "Approved") :
                          statusVal === "Draft" ? (language === "de" ? "Entwurf" : "Draft") :
                          (language === "de" ? "Überarbeiten" : "Needs Work");

                        return (
                          <button
                            key={statusVal}
                            type="button"
                            onClick={() => handleUpdatePresetStatus(preset.id, isCurrent ? undefined : statusVal)}
                            className={`px-1.5 py-[2px] rounded border text-[6px] font-mono leading-none transition cursor-pointer select-none ${
                              isCurrent ? activeColorClasses : colorClasses
                            }`}
                            title={language === "de" ? `Als '${labelText}' markieren` : `Mark as '${labelText}'`}
                          >
                            {labelText}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </>
              ) : (
                <div className="flex flex-col gap-1 mt-0.5 pointer-events-auto shrink-0 bg-slate-950/40 p-1.5 rounded border border-slate-900/40 h-[150px]">
                  <div className="flex flex-col gap-1 h-full overflow-y-auto scrollbar-thin pr-1">
                    {preset.statusHistory && preset.statusHistory.length > 0 ? (
                      [...preset.statusHistory].reverse().map((entry: any, i: number, arr: any[]) => {
                        const date = new Date(entry.timestamp);
                        const timeStr = `${date.toLocaleDateString()} ${date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', second: '2-digit'})}`;
                        const prevEntry = arr[i + 1];
                        const prevStatus = prevEntry ? prevEntry.status : (language === "de" ? "Erstellt" : "Created");
                        
                        return (
                          <div key={i} className="flex flex-col gap-0.5 text-[6px] border-b border-slate-800/50 pb-1.5 pt-0.5 last:border-0 last:pb-0">
                            <div className="flex items-center justify-between mb-0.5">
                              <span className="text-slate-300 font-bold flex items-center gap-1.5">
                                <span className="text-slate-500 line-through decoration-slate-600 truncate max-w-[45px] block font-mono font-normal opacity-80">{prevStatus}</span>
                                <ArrowRight className="h-2 w-2 text-slate-600 shrink-0" />
                                <span className={`font-mono text-[6.5px] ${entry.status === "Approved" ? "text-emerald-400" : entry.status === "Needs Work" ? "text-amber-400" : entry.status === "Draft" ? "text-slate-300" : "text-cyan-400"}`}>
                                  {entry.status}
                                </span>
                              </span>
                              <span className="text-slate-500 text-[5px] font-mono opacity-80">{timeStr}</span>
                            </div>
                            <div className="flex items-center justify-start">
                              <span className="text-slate-400 font-mono flex items-center gap-1 bg-slate-900/50 px-1 py-0.5 rounded text-[5px] border border-slate-800/50">
                                <User className="h-1.5 w-1.5 text-cyan-500/70" />
                                {entry.user}
                              </span>
                            </div>
                          </div>
                        );
                      })
                    ) : (
                      <div className="text-slate-500 text-center flex flex-col items-center justify-center h-full text-[6px]">
                        <Clock className="h-4 w-4 mb-1 opacity-20" />
                        {language === "de" ? "Keine Historie vorhanden" : "No history available"}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          );
        })()}"""

with open("src/App.tsx", "w") as f:
    f.write(content[:idx_start] + new_content + content[idx_end:])

print("Successfully replaced.")
