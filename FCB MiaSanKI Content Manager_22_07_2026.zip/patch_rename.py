import re

with open("src/App.tsx", "r") as f:
    content = f.read()

target = """                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setEditingCategoryPath(cat);
                      setEditingCategoryValue(cat.split("/").pop() || cat);
                    }}
                    className="text-slate-500 hover:text-cyan-400 p-0.5 transition cursor-pointer"
                    title={language === "de" ? "Bereich umbenennen" : "Rename category"}
                  >
                    <Edit2 className="h-2.5 w-2.5" />
                  </button>"""

replacement = """                  {(!["Technical", "Creative"].includes(cat)) && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setEditingCategoryPath(cat);
                        setEditingCategoryValue(cat.split("/").pop() || cat);
                      }}
                      className="text-slate-500 hover:text-cyan-400 p-0.5 transition cursor-pointer"
                      title={language === "de" ? "Bereich umbenennen" : "Rename category"}
                    >
                      <Edit2 className="h-2.5 w-2.5" />
                    </button>
                  )}"""

if target in content:
    content = content.replace(target, replacement)
    with open("src/App.tsx", "w") as f:
        f.write(content)
    print("Replaced successfully")
else:
    print("Target not found")
