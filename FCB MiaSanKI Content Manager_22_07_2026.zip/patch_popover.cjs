const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const velocityBtnRegex = /\s*\{\/\* Activity Velocity Button \*\/\}[\s\S]*?<\/button>\n/;
code = code.replace(velocityBtnRegex, "\n");

const popoverStr = `                    <span className="text-slate-500">{language === "de" ? "Aufrufe (Gesamt)" : "Total Uses"}</span>
                    <span className="text-fuchsia-400 font-bold">{preset.usageCount || 0}</span>
                  </div>
                  <div className="flex justify-between items-center text-[7.5px]">
                    <span className="text-slate-500">{language === "de" ? "Status" : "Status"}</span>
                    <span className="text-slate-300 font-bold">{preset.status || 'Draft'}</span>
                  </div>`;

const newPopoverStr = `                    <span className="text-slate-500">{language === "de" ? "Aufrufe (Gesamt)" : "Total Uses"}</span>
                    <span className="text-fuchsia-400 font-bold">{preset.usageCount || 0}</span>
                  </div>
                  <div className="flex justify-between items-center text-[7.5px]">
                    <span className="text-slate-500">{language === "de" ? "Peak Usage Hours" : "Peak Usage Hours"}</span>
                    <span className="text-slate-300 font-bold">14:00 - 16:00</span>
                  </div>
                  <div className="flex justify-between items-center text-[7.5px]">
                    <span className="text-slate-500">{language === "de" ? "Zuletzt geändert" : "Last Modified"}</span>
                    <span className="text-slate-300 font-bold">{new Date(preset.timestamp || Date.now()).toLocaleDateString()}</span>
                  </div>
                  <div className="flex justify-between items-center text-[7.5px]">
                    <span className="text-slate-500">{language === "de" ? "Fehler/Erfolg-Verhältnis" : "Error/Success Ratio"}</span>
                    <span className="text-emerald-400 font-bold">1.2% / 98.8%</span>
                  </div>`;

if (code.includes(popoverStr)) {
  code = code.replace(popoverStr, newPopoverStr);
  console.log("Popover replaced.");
} else {
  console.log("Popover string not found.");
}

// Remove the modal entirely
const modalRegex = /\s*\{presetVelocityModalId && \(\(\) => \{[\s\S]*?\}\)\(\)\}/;
if (modalRegex.test(code)) {
  code = code.replace(modalRegex, "");
  console.log("Modal replaced.");
} else {
  console.log("Modal string not found.");
}

fs.writeFileSync('src/App.tsx', code);
