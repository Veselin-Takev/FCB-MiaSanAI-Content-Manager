const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

code = code.replace(
  /onContextMenu=\{\(e\) => \{\s+e\.preventDefault\(\);\s+e\.stopPropagation\(\);\s+setSidebarContextMenu\(\{ x: e\.clientX, y: e\.clientY, folderPath: cat \}\);\s+\}\}/g,
  `onContextMenu={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setInTreeCategoryCreatePath(cat);
                setInTreeCategoryInputValue("");
                setExpandedFolders(prev => ({ ...prev, [cat]: true }));
              }}`
);

code = code.replace(
  /onContextMenu=\{\(e\) => \{\s+e\.preventDefault\(\);\s+e\.stopPropagation\(\);\s+setSidebarContextMenu\(\{ x: e\.clientX, y: e\.clientY, folderPath: subfolder\.fullPath \}\);\s+\}\}/g,
  `onContextMenu={(e) => {
              e.preventDefault();
              e.stopPropagation();
              setInTreeCategoryCreatePath(subfolder.fullPath);
              setInTreeCategoryInputValue("");
              setExpandedFolders(prev => ({ ...prev, [subfolder.fullPath]: true }));
            }}`
);

// Remove the sidebarContextMenu UI entirely
const sidebarContextMenuRegex = /<AnimatePresence>\s*\{sidebarContextMenu && \([\s\S]*?<\/AnimatePresence>/;
code = code.replace(sidebarContextMenuRegex, "");

fs.writeFileSync('src/App.tsx', code);
