const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

// 1. Remove the old undoStack and redoStack useStates
code = code.replace(/const \[undoStack, setUndoStack\] = useState<\{ id: string; description: string; descriptionDe: string; presets: any\[\] \}\[\]>\(\[\]\);\n\s*const \[redoStack, setRedoStack\] = useState<\{ id: string; description: string; descriptionDe: string; presets: any\[\] \}\[\]>\(\[\]\);/g, "");

// 2. Add the reducer definition outside the component (before function App())
const reducerCode = `interface HistorySnapshot {
  id: string;
  description: string;
  descriptionDe: string;
  presets: any[];
}

type UndoRedoAction = 
  | { type: 'PUSH_SNAPSHOT'; description: string; descriptionDe: string; currentPresets: any[] }
  | { type: 'UNDO'; currentPresets: any[] }
  | { type: 'REDO'; currentPresets: any[] }
  | { type: 'CLEAR' };

interface UndoRedoState {
  past: HistorySnapshot[];
  future: HistorySnapshot[];
}

const undoRedoReducer = (state: UndoRedoState, action: UndoRedoAction): UndoRedoState => {
  switch (action.type) {
    case 'PUSH_SNAPSHOT':
      return {
        past: [...state.past, {
          id: \\\`undo-\\\${Date.now()}\\\`,
          description: action.description,
          descriptionDe: action.descriptionDe,
          presets: JSON.parse(JSON.stringify(action.currentPresets))
        }].slice(-20),
        future: []
      };
    case 'UNDO':
      if (state.past.length === 0) return state;
      const previous = state.past[state.past.length - 1];
      return {
        past: state.past.slice(0, state.past.length - 1),
        future: [...state.future, {
          id: \\\`redo-\\\${Date.now()}\\\`,
          description: previous.description,
          descriptionDe: previous.descriptionDe,
          presets: JSON.parse(JSON.stringify(action.currentPresets))
        }].slice(-20)
      };
    case 'REDO':
      if (state.future.length === 0) return state;
      const next = state.future[state.future.length - 1];
      return {
        past: [...state.past, {
          id: \\\`undo-\\\${Date.now()}\\\`,
          description: next.description,
          descriptionDe: next.descriptionDe,
          presets: JSON.parse(JSON.stringify(action.currentPresets))
        }].slice(-20),
        future: state.future.slice(0, state.future.length - 1)
      };
    case 'CLEAR':
      return { past: [], future: [] };
    default:
      return state;
  }
};

export default function App() {`;

code = code.replace(/export default function App\(\) \{/, reducerCode);

// 3. Add useReducer in App
code = code.replace(/const \[exportPresets, setExportPresets\] = useLocalStorage<ExportPreset\[\]>\("fcb_miasanai_export_presets", AUTOMATION_PRESETS\);/g, 
  `const [exportPresets, setExportPresets] = useLocalStorage<ExportPreset[]>("fcb_miasanai_export_presets", AUTOMATION_PRESETS);\n  const [historyState, dispatchHistory] = React.useReducer(undoRedoReducer, { past: [], future: [] });`);

// 4. Update pushToUndoStack and handleBulkUndo / handleBulkRedo
const handlersRegex = /const pushToUndoStack = \([\s\S]*?\}\);\n  \};\n/g;
const newHandlers = `const pushToUndoStack = (desc: string, descDe: string) => {
    dispatchHistory({ type: 'PUSH_SNAPSHOT', description: desc, descriptionDe: descDe, currentPresets: exportPresets });
  };

  const handleBulkUndo = () => {
    if (historyState.past.length === 0) return;
    const lastOp = historyState.past[historyState.past.length - 1];
    
    dispatchHistory({ type: 'UNDO', currentPresets: exportPresets });
    
    setExportPresets(lastOp.presets);
    try {
      localStorage.setItem("fcb_miasanai_export_presets", JSON.stringify(lastOp.presets));
    } catch (e) {
      console.error(e);
    }
    
    handleAddLog({
      id: \\\`undo-applied-\\\${Date.now()}\\\`,
      timestamp: new Date().toLocaleTimeString(),
      source: "Preset Manager",
      level: "SUCCESS",
      message: language === "de" 
        ? \\\`Letzte Aktion rückgängig gemacht: \\\${lastOp.descriptionDe}\\\` 
        : \\\`Undid last action: \\\${lastOp.description}\\\`
    });
  };

  const handleBulkRedo = () => {
    if (historyState.future.length === 0) return;
    const nextOp = historyState.future[historyState.future.length - 1];
    
    dispatchHistory({ type: 'REDO', currentPresets: exportPresets });
    
    setExportPresets(nextOp.presets);
    try {
      localStorage.setItem("fcb_miasanai_export_presets", JSON.stringify(nextOp.presets));
    } catch (e) {
      console.error(e);
    }
    
    handleAddLog({
      id: \\\`redo-applied-\\\${Date.now()}\\\`,
      timestamp: new Date().toLocaleTimeString(),
      source: "Preset Manager",
      level: "SUCCESS",
      message: language === "de" 
        ? \\\`Aktion wiederhergestellt: \\\${nextOp.descriptionDe}\\\` 
        : \\\`Redid action: \\\${nextOp.description}\\\`
    });
  };\n`;

code = code.replace(handlersRegex, newHandlers.replace(/\\\\/g, ""));

// 5. Update UI rendering references from undoStack to historyState.past
const uiOld = `{undoStack.length > 0 && (
                                            <button
                                              type="button"
                                              onClick={handleBulkUndo}
                                              className="flex items-center gap-1.5 py-1 px-2.5 bg-rose-950/20 border border-rose-900/40 hover:bg-rose-900/40 hover:border-rose-500/50 rounded transition-all cursor-pointer text-[8px] font-mono font-bold text-rose-400"
                                              title={language === "de" ? undoStack[undoStack.length - 1].descriptionDe : undoStack[undoStack.length - 1].description}
                                            >
                                              <Undo2 className="h-3 w-3 shrink-0" />
                                              {language === "de" ? "Undo" : "Undo"}
                                            </button>
                                          )}
                                          {redoStack.length > 0 && (
                                            <button
                                              type="button"
                                              onClick={handleBulkRedo}
                                              className="flex items-center gap-1.5 py-1 px-2.5 bg-cyan-950/20 border border-cyan-900/40 hover:bg-cyan-900/40 hover:border-cyan-500/50 rounded transition-all cursor-pointer text-[8px] font-mono font-bold text-cyan-400"
                                              title={language === "de" ? redoStack[redoStack.length - 1].descriptionDe : redoStack[redoStack.length - 1].description}
                                            >
                                              <Redo2 className="h-3 w-3 shrink-0" />
                                              {language === "de" ? "Redo" : "Redo"}
                                            </button>
                                          )}`;

const uiNew = `{historyState.past.length > 0 && (
                                            <button
                                              type="button"
                                              onClick={handleBulkUndo}
                                              className="flex items-center gap-1.5 py-1 px-2.5 bg-rose-950/20 border border-rose-900/40 hover:bg-rose-900/40 hover:border-rose-500/50 rounded transition-all cursor-pointer text-[8px] font-mono font-bold text-rose-400"
                                              title={language === "de" ? historyState.past[historyState.past.length - 1].descriptionDe : historyState.past[historyState.past.length - 1].description}
                                            >
                                              <Undo2 className="h-3 w-3 shrink-0" />
                                              {language === "de" ? "Undo" : "Undo"}
                                            </button>
                                          )}
                                          {historyState.future.length > 0 && (
                                            <button
                                              type="button"
                                              onClick={handleBulkRedo}
                                              className="flex items-center gap-1.5 py-1 px-2.5 bg-cyan-950/20 border border-cyan-900/40 hover:bg-cyan-900/40 hover:border-cyan-500/50 rounded transition-all cursor-pointer text-[8px] font-mono font-bold text-cyan-400"
                                              title={language === "de" ? historyState.future[historyState.future.length - 1].descriptionDe : historyState.future[historyState.future.length - 1].description}
                                            >
                                              <Redo2 className="h-3 w-3 shrink-0" />
                                              {language === "de" ? "Redo" : "Redo"}
                                            </button>
                                          )}`;

code = code.replace(uiOld, uiNew);

fs.writeFileSync('src/App.tsx', code);
console.log("Patched to Redux style!");
