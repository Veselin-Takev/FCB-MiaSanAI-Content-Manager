const fs = require('fs');
const code = fs.readFileSync('src/App.tsx', 'utf8');
const lines = code.split('\n');
const start = lines.findIndex(l => l.includes('const handleRenameCustomCategory ='));
console.log(lines.slice(start, start+40).join('\n'));
