import re

with open("src/App.tsx", "r") as f:
    content = f.read()

# Update getFilteredPresets dependencies
content = content.replace(
    "}, [exportPresets, activeSeasonFilter, activeMatchdayFilter, activeTagsFilter, tagSearchQuery, exportPresetSearchQuery, exportPresetStatusFilter]);",
    "}, [exportPresets, activeSeasonFilter, activeMatchdayFilter, activeTagsFilter, tagSearchQuery, exportPresetSearchQuery, exportPresetStatusFilter, presetDeepSearchQuery]);"
)

# Add deep search logic
deep_search_logic = """
      if (exportPresetStatusFilter !== "All" && p.status !== exportPresetStatusFilter) return false;

      if (presetDeepSearchQuery) {
        const dq = presetDeepSearchQuery.toLowerCase().trim();
        const matchesDeep = (p.description && p.description.toLowerCase().includes(dq)) || 
                            (p.notes && p.notes.toLowerCase().includes(dq)) || 
                            (p.name && p.name.toLowerCase().includes(dq)) || 
                            (p.nameDe && p.nameDe.toLowerCase().includes(dq));
        if (!matchesDeep) return false;
      }

      if (!exportPresetSearchQuery) return true;
"""

content = content.replace(
    """      if (exportPresetStatusFilter !== "All" && p.status !== exportPresetStatusFilter) return false;

      if (!exportPresetSearchQuery) return true;""",
    deep_search_logic
)

with open("src/App.tsx", "w") as f:
    f.write(content)
